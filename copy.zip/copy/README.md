# copy：已训练模型与最小运行文件

本目录只包含**推理所需**的模型权重、源码、冻结配置、依赖清单和演示图，**不包含训练数据集**。
四个模型均来自本机已完成的实验，权重未重新训练。

## 目录

| 路径 | 内容 |
|---|---|
| `src/apple_counter/` | 小图 ResNet18 与果园 YOLO 的预测代码 |
| `src/core_counter/` | 核心区域计数 v1 的预测代码 |
| `runs/counting/best.pt` | 苹果簇 ResNet18（0–6 分类） |
| `runs/detector/weights/best.pt` | YOLO11n 果园检测，原默认模型 |
| `runs/detector_s_tiled/weights/best.pt` | YOLO11s 分块实验模型，未通过升级门槛 |
| `runs/core_v1/best.pt` | 核心区域计数 v1 实验模型，未通过升级门槛 |
| `results/optimization/selection.json` | 默认果园配置（仍指向 YOLO11n 整图） |
| `results/optimization/s_tiled/selection.json` | 实验分块配置 |
| `results/detection/selection.json` | 旧 YOLO11n 冻结选择（仅路径改为相对） |
| `runs/core_v1/selection.json` | 核心计数 v1 的可移植冻结选择 |
| `runs/core_v1/protocol.json` | 核心计数 v1 冻结协议快照 |
| `demo/` | 3 张果园图、14 张小图，可直接试跑 |
| `docs/` | 已保存的实测指标与结果说明 |
| `run.py` | 已测试的 Python 启动脚本，自动设置缓存和 PYTHONPATH |
| `run.ps1` | PowerShell 等价启动脚本（执行策略受限时用 `run.py`） |
| `gui.py` | 英文图形界面：拖拽或导入图片即自动检测 |
| `Start GUI.bat` | Windows 双击启动图形界面 |
| `vendor/` | 内置 tkinterdnd2，拖拽支持无需额外安装 |

## 环境

需要 Python 3.12、PyTorch、torchvision、Ultralytics、OpenCV、Pillow、NumPy：

```powershell
pip install -r requirements.txt
```

本机已验证的 Python：

```text
C:\Users\30237\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe
```

CPU 可以运行全部推理；GPU 可选。不要为了跑通而升级共享环境。

## 快速运行

在 `copy` 根目录打开 PowerShell：

```powershell
# 1) 苹果簇小图（只支持 0--6 个苹果）
python run.py patch demo/patch predictions/patch

# 2) 默认果园模型（YOLO11n 整图，推荐）
python run.py orchard demo/orchard predictions/orchard

# 3) 实验分块模型（YOLO11s，仅供参考，未通过升级门槛）
python run.py tiled demo/orchard predictions/tiled

# 4) 核心区域计数 v1（实验，未通过升级门槛；输入必须是单张图）
python run.py core demo/orchard/dataset1_back_1.png predictions/core
```

PowerShell 等价入口：`.\run.ps1 -Model orchard -Source demo/orchard -Output predictions/orchard`。
若系统执行策略阻止 `.ps1`，使用上面的 `run.py`。

如果不用脚本，等价命令：

```powershell
$env:PYTHONPATH="$PWD\src"
python -m apple_counter.predict demo/orchard --mode orchard --selection results/optimization/selection.json --out predictions/orchard --device cpu
```

核心计数 v1：

```powershell
$env:PYTHONPATH="$PWD\src"
python -m core_counter.predict --image demo/orchard/dataset1_back_1.png --selection runs/core_v1/selection.json --output predictions/core/result.json --device cpu
```

`run.py` 使用当前 Python 解释器；若 `python` 不在 PATH，可直接指定：

```powershell
& 'C:\Users\30237\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe' run.py orchard demo/orchard predictions/orchard
```

## 图形界面（拖拽检测）

双击 `Start GUI.bat`，或在终端执行：

```powershell
python gui.py
```

使用方式：

- 把图片拖进窗口即自动检测；也可以点 **Open Image...** 选择本地图片。
- 右侧 **Result** 小框显示预测数量、模型、文件名、耗时。
- 右上角 **Close** 关闭程序。
- **Model** 可选 Orchard（默认）、Tiled、Patch、Core。
- 支持 PNG / JPG / JPEG / BMP / WEBP；一次拖入多张时只处理第一张。
- 结果与标注图保存在 `gui_output/` 下，每次检测一个子目录。

说明：首次检测约需 7–9 秒，因为每次会重新加载模型；这是简单工具，不是实时视频检测。拖拽功能由内置 `vendor/tkinterdnd2` 提供，不需要额外 `pip install`。如果界面提示拖拽不可用，仍可用 **Open Image...**。Linux 还需要系统安装 `python3-tk`。

## 模型选择建议

- **默认用 `orchard`（YOLO11n 整图）**。官方 331 张复用测试 MAE 约 7.42。
- `tiled` 在密集内部序列上更好（MAE 40.65 vs 46.96），但官方测试明显更差（13.77 vs 7.42），且未通过验证门槛。
- `core` 核心计数 v1 验证 MAE 6.83、内部 59.05、官方 14.13，均未超过旧基线，仅作实验记录。
- `patch` 只用于已经裁好的苹果簇小图，不要输入完整果园图。

## 完整性

`MANIFEST.json` 记录包内每个文件的 SHA256 和字节数，并列出四个权重的哈希。
`results/detection/selection.json` 仅把绝对权重路径改为相对路径，`weights_sha256` 未变；核心 v1 使用原有的可移植选择文件。
运行 `core` 时，代码会校验权重、协议和训练源码哈希；若修改 `src/core_counter` 中的模型/几何/数据代码，校验会拒绝加载。

## 限制

这些是研究/课程实验权重，不是生产级通用果园计数器。密集、遮挡、新果园/新光照下可能明显退化；测试集此前已查看，指标是复用对照而非新盲测。模型与 Ultralytics/MinneApple 的许可义务仍由使用者核实。
