# 苹果计数优化结果

## 结论

**未通过预先规定的防过拟合升级门槛，默认保留原基线；新分块模型仅作为实验方案交付。** 默认配置 **baseline_full**，置信度 **0.35**，推理模式 **full**。小图ResNet18未改动，既有小图测试结果保持不变。

默认权重和阈值保持不变，不声称默认方案有精度提升。基线本轮重跑官方MAE为7.425982，v1存档为7.422961，有轻微非逐位复现差异；下表保留v1存档基线，原始复跑数据也完整保存，不把微小差异当成改进。 这些是已经看过的测试集上的对照，不是新的盲测；不以其表现改变模型或阈值。

实验分块模型的密集序列MAE由 46.96 降至 40.65，但官方复用测试MAE由 7.42 升至 13.77。召回提高伴随误检增加，不能视为整体升级，也不据此做测试专用阈值。

## 1. 防过拟合措施

- 原图分组始终为466训练 /104验证 /100内部测试；所有裁块继承父图划分，没有将邻帧随机打散，也没有把密集测试序列放回训练。
- 只进行**一次**YOLO11s训练，COCO初始化；完整图+720重叠块混合训练。1398训练视图来自466父图，不是1398独立样本，训练量也不与旧模型等量。
- 最多50轮，patience10，实际训练**17轮**；训练日志的最佳验证mAP50-95在**第7轮**，采用自动保存的best.pt，不手挑测试表现好的轮次。
- 固定四个候选、五个置信度，不扩展分辨率/重叠比例/NMS参数搜索。接缝保留目标片段，经原图坐标全局NMS与跨块边缘片段去重，避免简单删除边框目标造成漏计。
- A序列选阈值、B序列评价，再交换；升级要求两个序列均至少改善5%，跨序列平均与图像加权MAE均改善至少10%，RMSE不得退步；部署阈值的两个序列也不得退步。
- 训练前对[实验方案](<optimization_protocol.json>)、原图分组和分块清单进行SHA256锁定；验证后对配置及checkpoint再次锁定。两组验证太少，crossfit只检验校准迁移，不是独立模型验证或统计显著性证明。

## 2. 验证集比较（决定升级，不使用测试集）

| 候选 | 两序列平均 MAE（联合校准） | 跨序列校准 MAE | 联合校准阈值 | 是否通过升级门槛 |
|---|---:|---:|---:|---|
| baseline_full | 4.247 | 4.247 | 0.35 | 基线对照 |
| baseline_tiled | 5.329 | 5.329 | 0.45 | 未通过 |
| s_full | 4.324 | 4.324 | 0.35 | 未通过 |
| s_tiled | 4.491 | 4.491 | 0.35 | 未通过 |

未通过的具体原因：
- **baseline_tiled**：crossfit macro MAE improvement below10%；crossfit aggregate MAE improvement below10%；crossfit RMSE regression；crossfit sequence improvement below5%: 20150921_132245；crossfit sequence improvement below5%: 20150921_131453；deployment aggregate MAE improvement below10%；deployment RMSE regression；deployment sequence regression: 20150921_131453；deployment sequence regression: 20150921_132245
- **s_full**：crossfit macro MAE improvement below10%；crossfit aggregate MAE improvement below10%；crossfit sequence improvement below5%: 20150921_132245；crossfit sequence improvement below5%: 20150921_131453；deployment aggregate MAE improvement below10%；deployment sequence regression: 20150921_131453
- **s_tiled**：crossfit macro MAE improvement below10%；crossfit aggregate MAE improvement below10%；crossfit sequence improvement below5%: 20150921_132245；deployment aggregate MAE improvement below10%；deployment sequence regression: 20150921_132245

完整逐序列数值、阈值网格和交叉校准方向见[验证对照JSON](<results/optimization/comparison_validation.json>)。

## 3. 冻结后的测试对照

| 模型 / 配置 | 集合 | MAE ↓ | RMSE ↓ | 偏差 | 完全正确率 |
|---|---|---:|---:|---:|---:|
| baseline_full | 官方测试复用 | 7.423 | 9.448 | +1.858 | 6.34% |
| baseline_full | 高密度内部测试复用 | 46.960 | 57.244 | -46.220 | 5.00% |
| s_tiled | 官方测试复用 | 13.773 | 17.645 | +11.798 | 1.81% |
| s_tiled | 高密度内部测试复用 | 40.650 | 49.585 | -39.730 | 5.00% |

![测试MAE对照](<results/optimization/figures/test_comparison.png>)

只评估预先固定的选中方案和实验分块方案（若不同）。没有依据测试表重新选择赢家、追加训练或修改阈值。旧版[完整结果](<RESULTS.md>)保留供核对。不能将总数量误差较小解释为每张图均准确。

## 4. 训练与局限

![早停曲线](<results/optimization/figures/training_early_stop.png>)

训练与验证增强不同，损失曲线不是同一输入任务；早停说明验证指标未继续提升，并不证明已完全排除过拟合。只有两个验证序列；模型结构、训练曝光量与分块增强同时变化，不能把提升全部归因于某单一因素。跨块片段合并也可能错合重叠的真实苹果，存在定位与计数误差。要进一步证明泛化，应采集新的独立果园/拍摄日期图像，再进行一次真正盲测。

## 5. 运行

完整数据环境的 **123项自动化测试全部通过**，包含原基线回归、分块标签、接缝去重、跨序列校准隔离、哈希锁和优化推理入口。测试记录见[测试日志](<results/optimization/test_report.txt>)。交付包隔离解压后117项通过、6项需完整数据的集成测试按设计跳过；旧版与实验模型均完成3张演示图的CPU推理，与GPU计数一致，见[交付核验](<results/optimization/delivery_smoke.json>)。单元测试通过不代表预测精度提升。

默认推理自动读取本次冻结配置：

```bash
python -m apple_counter.predict demo/orchard --mode orchard --out predictions_optimized
```

强制使用旧版基线：

```bash
python -m apple_counter.predict demo/orchard --mode orchard --selection results/detection/selection.json --out predictions_baseline
```

仅用于实验查看的新分块方案（不代表通过升级门槛）：

```bash
python -m apple_counter.predict demo/orchard --mode orchard --selection results/optimization/s_tiled/selection.json --out predictions_tiled
```

[Colab入口](<Apple_Counting_Colab.ipynb>)、[使用说明](<README.md>)。本机训练与推理已实际执行，Colab云端仍未实测。模型及MinneApple数据沿用上游许可，不能声称适用于所有果园或被完全遮挡苹果的真实总量。
