"""Count 0--6 apples in an already cropped cluster; not an orchard detector."""
from pathlib import Path
import argparse, csv, json, time
import numpy as np
import cv2
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from torchvision.models import resnet18, ResNet18_Weights
from .common import seed_everything, count_metrics, save_json


class PatchDataset(Dataset):
    def __init__(self, root, split='train', size=96, augment=False, policy=None):
        root=Path(root); self.size=size; self.augment=augment
        if split=='test':
            base=root/'test_data/counting'
            labels=json.loads((base/'ground_truth.json').read_text())
            self.rows=[(base/'images'/name,int(y)) for name,y in sorted(labels.items())]
        else:
            base=root/'counting'/split
            with (base/f'{split}_ground_truth.txt').open(newline='') as f:
                self.rows=[(base/'images'/r['Image'],int(r['count'])) for r in csv.DictReader(f)]
        if policy and split in ('train','val'):
            exclusions=set(policy[f'{split}_exclude'])
            self.rows=[(p,y) for p,y in self.rows if p.name not in exclusions]
        missing=[str(p) for p,y in self.rows if not p.is_file()]
        if missing: raise FileNotFoundError(f'{len(missing)} images absent: {missing[:3]}')
        self.targets=np.array([y for p,y in self.rows])
        if self.targets.min()<0 or self.targets.max()>6:
            raise ValueError('Patch model is defined for count classes 0..6 only')
    def __len__(self): return len(self.rows)
    def __getitem__(self,i):
        p,y=self.rows[i]; im=cv2.imread(str(p))
        if im is None: raise ValueError(f'Cannot read {p}')
        im=cv2.cvtColor(cv2.resize(im,(self.size,self.size)),cv2.COLOR_BGR2RGB)
        # No random crop: cropping apples would invalidate image-level count labels.
        if self.augment:
            if np.random.random()<.5: im=im[:,::-1]
            if np.random.random()<.5: im=im[::-1]
            im=np.rot90(im,np.random.randint(4))
            im=np.clip(im.astype(np.float32)*np.random.uniform(.8,1.2)+np.random.uniform(-10,10),0,255)
        x=torch.from_numpy(np.ascontiguousarray(im.transpose(2,0,1))).float()/255
        return x,y,i


class PatchCounter(nn.Module):
    def __init__(self,pretrained=False):
        super().__init__()
        self.net=resnet18(weights=ResNet18_Weights.DEFAULT if pretrained else None)
        self.net.fc=nn.Linear(self.net.fc.in_features,7)
        self.register_buffer('mean',torch.tensor([.485,.456,.406]).view(1,3,1,1))
        self.register_buffer('std',torch.tensor([.229,.224,.225]).view(1,3,1,1))
    def forward(self,x): return self.net((x-self.mean)/self.std)


def decode(prob,method):
    prob=np.asarray(prob)
    if prob.ndim!=2 or prob.shape[1]!=7 or not np.isfinite(prob).all() or (prob<0).any() or not np.allclose(prob.sum(1),1,atol=1e-3):
        raise ValueError('Expected finite normalized N x 7 probabilities')
    if method=='mode': return prob.argmax(1)
    if method=='median': return (np.cumsum(prob,axis=1)<.5).sum(1).clip(0,6)
    if method=='rounded_mean': return np.rint(prob@np.arange(7)).astype(int)
    raise ValueError(method)


@torch.inference_mode()
def probabilities(model,loader,device,tta=False):
    model.eval(); ps=[]; ys=[]
    for x,y,_ in loader:
        x=x.to(device,non_blocking=True)
        with torch.autocast(device_type=device.type, enabled=device.type=='cuda'):
            p=model(x).softmax(1)
            if tta: p=(p+model(x.flip(-1)).softmax(1))/2
        ps.append(p.float().cpu().numpy()); ys.extend(y.tolist())
    return np.concatenate(ps),np.asarray(ys)


def train(args):
    seed_everything(args.seed)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    policy=json.loads(Path(args.policy).read_text()) if args.policy else None
    tr=PatchDataset(args.data,'train',args.size,True,policy); va=PatchDataset(args.data,'val',args.size,policy=policy)
    dlargs=dict(batch_size=args.batch, num_workers=args.workers,pin_memory=device.type=='cuda',
                persistent_workers=args.workers>0)
    train_dl=DataLoader(tr,shuffle=True,**dlargs); val_dl=DataLoader(va,shuffle=False,**dlargs)
    model=PatchCounter(pretrained=not args.scratch).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=1e-4)
    sch=torch.optim.lr_scheduler.CosineAnnealingLR(opt,args.epochs,eta_min=args.lr/30)
    scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
    criterion=nn.CrossEntropyLoss()
    best=float('inf'); history=[]
    config=vars(args).copy(); config['device']=str(device)
    config['train_histogram']=np.bincount(tr.targets,minlength=7).tolist()
    config['val_histogram']=np.bincount(va.targets,minlength=7).tolist()
    config['torch_version']=str(torch.__version__)
    if policy:
        import hashlib
        config['policy_sha256']=hashlib.sha256(Path(args.policy).read_bytes()).hexdigest()
        config['train_n']=len(tr);config['val_n']=len(va)
    save_json(out/'config.json',config)
    print(json.dumps(config,indent=2),flush=True)
    for epoch in range(1,args.epochs+1):
        t=time.perf_counter(); model.train(); total=0.; seen=0
        for x,y,_ in train_dl:
            x=x.to(device,non_blocking=True); y=y.to(device,non_blocking=True)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,enabled=device.type=='cuda'):
                logits=model(x)
                expected=logits.softmax(1)@torch.arange(7,device=device,dtype=logits.dtype)
                loss=criterion(logits,y)+.15*nn.functional.smooth_l1_loss(expected,y.float())
            scaler.scale(loss).backward(); scaler.unscale_(opt)
            nn.utils.clip_grad_norm_(model.parameters(),5)
            scaler.step(opt); scaler.update()
            total+=loss.item()*len(y);seen+=len(y)
        prob,y=probabilities(model,val_dl,device)
        scores={m:count_metrics(y,decode(prob,m)) for m in ['mode','median','rounded_mean']}
        method=min(scores,key=lambda m:scores[m]['mae']); metric=scores[method]
        rec={'epoch':epoch,'loss':total/seen,'val':metric,'decode':method,'seconds':time.perf_counter()-t,'lr':opt.param_groups[0]['lr']}
        history.append(rec);save_json(out/'history.json',history)
        if metric['mae']<best:
            best=metric['mae']
            torch.save({'state_dict':model.state_dict(),'size':args.size,'decode':method,
                        'epoch':epoch,'validation':scores,'config':config},out/'best.pt')
        print(json.dumps(rec),flush=True); sch.step()
    # TTA is selected on validation only, never on test labels.
    model,ckpt=load_model(out/'best.pt',device)
    options={}
    for tta in [False,True]:
        prob,y=probabilities(model,val_dl,device,tta)
        for method in ['mode','median','rounded_mean']:
            options[f'{method}_tta{int(tta)}']=count_metrics(y,decode(prob,method))
    chosen=min(options,key=lambda k:options[k]['mae'])
    method,tta_string=chosen.rsplit('_tta',1)
    ckpt['decode']=method;ckpt['tta']=bool(int(tta_string));ckpt['validation_options']=options
    torch.save(ckpt,out/'best.pt'); save_json(out/'validation_selection.json',{'chosen':chosen,'options':options})
    print('Complete:',out/'best.pt','validation selection',chosen,flush=True)


def load_model(path,device):
    ckpt=torch.load(path,map_location=device,weights_only=False)
    model=PatchCounter().to(device);model.load_state_dict(ckpt['state_dict']);model.eval()
    return model,ckpt


def evaluate(args):
    seed_everything(42); device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model,ckpt=load_model(args.weights,device)
    policy=json.loads(Path(args.policy).read_text()) if args.policy else None
    ds=PatchDataset(args.data,args.split,ckpt['size'],policy=policy)
    dl=DataLoader(ds,batch_size=args.batch,num_workers=args.workers,pin_memory=device.type=='cuda')
    start=time.perf_counter(); prob,y=probabilities(model,dl,device,ckpt.get('tta',False))
    elapsed=time.perf_counter()-start; pred=decode(prob,ckpt['decode'])
    metrics=count_metrics(y,pred); metrics['seconds']=elapsed;metrics['images_per_second']=len(y)/elapsed
    metrics['checkpoint_epoch']=ckpt['epoch'];metrics['decode']=ckpt['decode'];metrics['tta']=ckpt.get('tta',False)
    metrics['per_count']={str(i):count_metrics(y[y==i],pred[y==i]) for i in np.unique(y)}
    metrics['macro_mae']=float(np.mean([v['mae'] for v in metrics['per_count'].values()]))
    metrics['macro_exact_accuracy']=float(np.mean([v['exact_accuracy'] for v in metrics['per_count'].values()]))
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    if args.split=='test' and policy:
        include=set(policy['test_clean_include'])
        clean=np.array([p.name in include for p,_ in ds.rows])
        metrics['strict_clean_subset']=count_metrics(y[clean],pred[clean])
        metrics['strict_clean_subset']['definition']='One lexicographic representative per pixel hash, no original train/val overlap, no conflicting test labels; fixed before model test evaluation.'
    save_json(out/f'{args.split}_metrics.json',metrics)
    with (out/f'{args.split}_predictions.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['image','true_count','predicted_count','expected_count','absolute_error'])
        for (p,_),a,b,pr in zip(ds.rows,y,pred,prob):w.writerow([p.name,int(a),int(b),float(pr@np.arange(7)),int(abs(a-b))])
    np.savez_compressed(out/f'{args.split}_probabilities.npz',probabilities=prob,targets=y)
    print(json.dumps(metrics,indent=2),flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    t=sub.add_parser('train');t.add_argument('--data',default='datasets');t.add_argument('--out',default='runs/counting')
    t.add_argument('--epochs',type=int,default=15);t.add_argument('--size',type=int,default=96)
    t.add_argument('--batch',type=int,default=256);t.add_argument('--workers',type=int,default=4)
    t.add_argument('--lr',type=float,default=.0005);t.add_argument('--seed',type=int,default=42);t.add_argument('--scratch',action='store_true')
    e=sub.add_parser('evaluate');e.add_argument('--data',default='datasets');e.add_argument('--out',default='results/counting')
    e.add_argument('--weights',default='runs/counting/best.pt');e.add_argument('--split',choices=['val','test'],default='test')
    e.add_argument('--batch',type=int,default=256);e.add_argument('--workers',type=int,default=4)
    for parser in [t,e]:parser.add_argument('--policy',default='audit_counting_split_policy.json',help='Frozen decoded-pixel decontamination manifest; empty string uses original split')
    args=p.parse_args(); train(args) if args.command=='train' else evaluate(args)


if __name__=='__main__':main()
