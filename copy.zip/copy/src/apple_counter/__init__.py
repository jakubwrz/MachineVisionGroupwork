"""Apple counting: patch classification and orchard object detection."""
