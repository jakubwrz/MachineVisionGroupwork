"""Overlapping-tile orchard inference with fixed global-coordinate deduplication."""
from pathlib import Path
import time
import cv2
import numpy as np
from .detection import validate_apple_model, validate_predictions


def global_nms(boxes,scores,iou_threshold=.5,edge_flags=None,tile_ids=None,edge_ios=.8):
    """Stable confidence-ordered NMS in original image coordinates (single class)."""
    boxes=np.asarray(boxes,dtype=float).reshape(-1,4)
    scores=np.asarray(scores,dtype=float)
    if scores.shape!=(len(boxes),) or not np.isfinite(boxes).all() or not np.isfinite(scores).all():
        raise ValueError('Finite aligned boxes and scores required')
    if not 0<=iou_threshold<=1:raise ValueError('IoU threshold must be in [0,1]')
    if len(boxes) and np.any(boxes[:,2:]<=boxes[:,:2]):raise ValueError('Boxes must have positive area')
    edges=np.zeros(len(boxes),dtype=bool) if edge_flags is None else np.asarray(edge_flags,dtype=bool)
    tiles=np.zeros(len(boxes),dtype=int) if tile_ids is None else np.asarray(tile_ids)
    if edges.shape!=(len(boxes),) or tiles.shape!=(len(boxes),):raise ValueError('Aligned edge flags and tile IDs required')
    if not 0<=edge_ios<=1:raise ValueError('Edge IoS must be in [0,1]')
    order=np.argsort(-scores,kind='stable');keep=[]
    areas=np.prod(boxes[:,2:]-boxes[:,:2],axis=1)
    while len(order):
        i=int(order[0]);keep.append(i);rest=order[1:]
        if not len(rest):break
        lt=np.maximum(boxes[i,:2],boxes[rest,:2]);rb=np.minimum(boxes[i,2:],boxes[rest,2:])
        inter=np.maximum(rb-lt,0).prod(1);iou=inter/np.maximum(areas[i]+areas[rest]-inter,1e-12)
        ios=inter/np.maximum(np.minimum(areas[i],areas[rest]),1e-12)
        fragment_duplicate=((edges[i]|edges[rest])&(tiles[i]!=tiles[rest])&(ios>=edge_ios))
        order=rest[(iou<=iou_threshold)&~fragment_duplicate]
    return np.asarray(keep,dtype=int)


def map_tile_boxes(boxes,scores,window,image_size,border_margin=2.,return_edges=False):
    """Translate/clip boxes and mark internal-edge fragments without dropping apples."""
    b=np.asarray(boxes,dtype=float).reshape(-1,4).copy();s=np.asarray(scores,dtype=float)
    if s.shape!=(len(b),):raise ValueError('Box/score mismatch')
    if not np.isfinite(b).all() or not np.isfinite(s).all():raise ValueError('Nonfinite predictions')
    x0,y0,x1,y1=window;width,height=image_size
    if not (0<=x0<x1<=width and 0<=y0<y1<=height):raise ValueError('Window outside image')
    if not np.isfinite(border_margin) or border_margin<0:raise ValueError('Nonnegative finite border margin required')
    keep=np.ones(len(b),dtype=bool);edges=np.zeros(len(b),dtype=bool)
    # A large apple may touch both tile edges. Keep both views until global dedup.
    if x0>0:edges |= b[:,0]<=border_margin
    if y0>0:edges |= b[:,1]<=border_margin
    if x1<width:edges |= b[:,2]>=(x1-x0-border_margin)
    if y1<height:edges |= b[:,3]>=(y1-y0-border_margin)
    b[:,[0,2]]+=x0;b[:,[1,3]]+=y0
    b[:,[0,2]]=b[:,[0,2]].clip(0,width);b[:,[1,3]]=b[:,[1,3]].clip(0,height)
    keep &= (b[:,2]>b[:,0])&(b[:,3]>b[:,1])
    return (b[keep],s[keep],edges[keep]) if return_edges else (b[keep],s[keep])


def infer_image(model,image,selection,device='0'):
    """Return below-threshold candidate boxes/scores; caller applies inclusive confidence."""
    validate_apple_model(model)
    im=cv2.imread(str(image)) if isinstance(image,(str,Path)) else np.asarray(image)
    if im is None or im.ndim!=3:raise ValueError(f'Unreadable RGB image: {image}')
    height,width=im.shape[:2];mode=selection.get('inference_mode','full')
    if mode=='full':
        r=model.predict(im,imgsz=selection['imgsz'],conf=.01,iou=selection.get('iou',.6),
                        max_det=500,device=device,verbose=False)[0]
        return r.boxes.xyxy.cpu().numpy(),r.boxes.conf.cpu().numpy()
    if mode!='tiled':raise ValueError(f'Unsupported inference mode: {mode}')
    from .prepare_tiled import tile_windows
    windows=tile_windows(width,height,selection.get('tile_size',720),selection.get('overlap',.22))
    all_boxes=[];all_scores=[];all_edges=[];all_tile_ids=[]
    for tile_id,window in enumerate(windows):
        x0,y0,x1,y1=window;crop=np.ascontiguousarray(im[y0:y1,x0:x1])
        r=model.predict(crop,imgsz=selection['imgsz'],conf=.01,iou=selection.get('iou',.6),
                        max_det=500,device=device,verbose=False)[0]
        b,s,edges=map_tile_boxes(r.boxes.xyxy.cpu().numpy(),r.boxes.conf.cpu().numpy(),window,(width,height),selection.get('border_margin',2.),return_edges=True)
        all_boxes.extend(b);all_scores.extend(s);all_edges.extend(edges);all_tile_ids.extend([tile_id]*len(b))
    boxes=np.asarray(all_boxes,dtype=float).reshape(-1,4);scores=np.asarray(all_scores,dtype=float)
    keep=global_nms(boxes,scores,selection.get('global_iou',.5),all_edges,all_tile_ids,selection.get('edge_ios',.8))[:500]
    return boxes[keep],scores[keep]


def run_tiled_predictions(model,records,selection,device='0'):
    predictions=[];start=time.perf_counter()
    for path,gt in records:
        boxes,scores=infer_image(model,path,selection,device)
        predictions.append({'image':Path(path).name,'boxes':boxes.tolist(),'scores':scores.tolist()})
    validate_predictions(records,predictions)
    return predictions,time.perf_counter()-start
