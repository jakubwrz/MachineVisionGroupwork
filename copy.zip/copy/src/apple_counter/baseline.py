"""Transparent HSV/morphology baseline; parameters selected on validation only."""
from pathlib import Path
import argparse,csv,json,itertools
import cv2
import numpy as np
cv2.setNumThreads(1)
from .counting import PatchDataset
from .common import count_metrics,save_json


def hsv_count(image, hue_limit=42, min_area=20, peak_distance=8):
    im=cv2.resize(image,(96,96))
    hsv=cv2.cvtColor(cv2.GaussianBlur(im,(3,3),0),cv2.COLOR_BGR2HSV)
    h,s,v=cv2.split(hsv)
    mask=(((h<=hue_limit)|(h>=165))&(s>=65)&(v>=55)).astype(np.uint8)*255
    mask=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    n,labels,stats,_=cv2.connectedComponentsWithStats(mask)
    cleaned=np.zeros_like(mask)
    for i in range(1,n):
        if stats[i,cv2.CC_STAT_AREA]>=min_area:cleaned[labels==i]=255
    dist=cv2.distanceTransform(cleaned,cv2.DIST_L2,5)
    peaks=((dist==cv2.dilate(dist,np.ones((peak_distance*2+1,peak_distance*2+1),np.uint8)))&(dist>=2)).astype(np.uint8)
    count=cv2.connectedComponents(peaks)[0]-1
    return int(min(count,6)),cleaned


def main():
    p=argparse.ArgumentParser();p.add_argument('--data',default='datasets');p.add_argument('--out',default='results/baseline')
    p.add_argument('--policy',default='audit_counting_split_policy.json')
    p.add_argument('--evaluate-test',action='store_true');a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    policy=json.loads(Path(a.policy).read_text()) if a.policy else None
    if not a.evaluate_test:
        va=PatchDataset(a.data,'val',policy=policy);tr=PatchDataset(a.data,'train',policy=policy)
        images=[cv2.imread(str(path)) for path,y in va.rows]; y=va.targets
        best=float('inf');selection=None;trials=[]
        for hue,area,distance in itertools.product([30,42,55],[20,50,100],[6,10,14]):
            cfg={'hue_limit':hue,'min_area':area,'peak_distance':distance}
            pred=[hsv_count(im,**cfg)[0] for im in images];m=count_metrics(y,pred)
            trials.append({'parameters':cfg,'mae':m['mae']})
            if m['mae']<best:best=m['mae'];selection=cfg
        median=int(np.median(tr.targets))
        save_json(out/'selection.json',{'parameters':selection,'train_median':median,'trials':trials})
        split='val';ds=va
    else:
        selected=json.loads((out/'selection.json').read_text());selection=selected['parameters'];median=selected['train_median']
        split='test';ds=PatchDataset(a.data,split)
    pred=[hsv_count(cv2.imread(str(path)),**selection)[0] for path,y in ds.rows]
    result={'hsv':count_metrics(ds.targets,pred),'constant_median':count_metrics(ds.targets,np.full(len(ds),median)),
            'parameters':selection,'constant':median}
    if split=='test' and policy:
        include=set(policy['test_clean_include']);mask=np.array([p.name in include for p,_ in ds.rows])
        result['strict_clean_subset']={'hsv':count_metrics(ds.targets[mask],np.array(pred)[mask]),
                                       'constant_median':count_metrics(ds.targets[mask],np.full(mask.sum(),median))}
    save_json(out/f'{split}_metrics.json',result)
    with (out/f'{split}_predictions.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['image','true_count','hsv_count','constant_count'])
        w.writerows((path.name,y,pred[i],median) for i,(path,y) in enumerate(ds.rows))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
