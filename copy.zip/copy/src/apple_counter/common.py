from pathlib import Path
import json, random
import numpy as np


def seed_everything(seed=42):
    import torch
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = True


def count_metrics(actual, predicted):
    y, p = np.asarray(actual, dtype=float), np.asarray(predicted, dtype=float)
    if y.ndim != 1 or p.ndim != 1 or y.size == 0 or y.shape != p.shape or not np.isfinite(y).all() or not np.isfinite(p).all():
        raise ValueError('Expected finite nonempty equal-shaped count vectors')
    e = p-y
    return {'n_images':len(y), 'mae':float(np.abs(e).mean()),
            'rmse':float(np.sqrt((e**2).mean())), 'bias':float(e.mean()),
            'exact_accuracy':float((p == y).mean()), 'within_one':float((np.abs(e)<=1).mean()),
            'true_total':int(y.sum()), 'predicted_total':float(p.sum()),
            'aggregate_relative_error':float(abs(p.sum()-y.sum())/max(y.sum(),1))}


def save_json(path, value):
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')
