"""Predict apple counts on an image or folder, with explicit patch/orchard mode."""
from pathlib import Path
import argparse,csv,json
import cv2
import numpy as np
import torch
from .counting import load_model,decode
from .common import seed_everything,save_json
from .detection import validate_apple_model,verify_selection_checkpoint


def predict(args):
    seed_everything(42);source=Path(args.source).resolve();out=Path(args.out).resolve()
    if source.is_file():
        paths=[source]
    else:
        if source==out:
            raise ValueError('Output directory must differ from the source directory')
        # Never re-ingest prior annotated outputs when output is nested in source.
        excluded=out if out.is_relative_to(source) else None
        paths=sorted(p for p in source.rglob('*')
                     if p.is_file() and p.suffix.lower() in {'.png','.jpg','.jpeg','.bmp','.webp'}
                     and (excluded is None or not p.resolve().is_relative_to(excluded)))
    if not paths:raise FileNotFoundError(f'No images outside output subtree: {source}')
    out.mkdir(parents=True,exist_ok=True)
    rows=[];details=[]
    if args.mode=='orchard':
        from ultralytics import YOLO
        selection=json.loads(Path(args.selection).read_text())
        weights=args.weights or selection.get('deployment_weights','runs/detector/weights/best.pt')
        verify_selection_checkpoint(selection,weights)
        model=YOLO(weights);validate_apple_model(model)
        for index,path in enumerate(paths):
            if selection.get('inference_mode')=='tiled':
                from .tiled import infer_image
                boxes,scores=infer_image(model,path,selection,args.device)
                keep=np.asarray(scores,dtype=float)>=selection['confidence'];boxes=boxes[keep];scores=scores[keep]
                annotated=cv2.imread(str(path));count=len(boxes)
                for b in boxes:
                    x1,y1,x2,y2=map(int,b);cv2.rectangle(annotated,(x1,y1),(x2,y2),(0,255,255),2)
                cv2.rectangle(annotated,(0,0),(annotated.shape[1],55),(20,20,20),-1)
                cv2.putText(annotated,f'Apples: {count} (tiled)',(15,38),cv2.FONT_HERSHEY_SIMPLEX,.9,(255,255,255),2)
                cv2.imwrite(str(out/f'{index:05d}_{path.stem}_count{count}.jpg'),annotated)
                details.append({'image':str(path),'count':count,'boxes':boxes.tolist(),'confidence':scores.tolist()})
                rows.append((str(path),count));print(f'{path.name}: {count}');continue
            # Same low-confidence NMS output and inclusive threshold as evaluation.
            result=model.predict(str(path),imgsz=selection['imgsz'],conf=.01,
                                 iou=selection['iou'],max_det=500,device=args.device,verbose=False)[0]
            # Compare promoted stored scores, just like evaluation's Python-list ->
            # float64 arrays; tensor scalar casting could otherwise change boundary ties.
            scores=result.boxes.conf.cpu().numpy().astype(float)
            keep=np.flatnonzero(scores>=selection['confidence']).tolist()
            result=result[keep]
            count=len(result.boxes);annotated=result.plot(labels=False)
            cv2.putText(annotated,f'Apples: {count}',(15,40),cv2.FONT_HERSHEY_SIMPLEX,1,(255,255,255),3)
            cv2.imwrite(str(out/f'{index:05d}_{path.stem}_count{count}.jpg'),annotated)
            details.append({'image':str(path),'count':count,'boxes':result.boxes.xyxy.cpu().numpy().tolist(),
                            'confidence':result.boxes.conf.cpu().numpy().tolist()})
            rows.append((str(path),count));print(f'{path.name}: {count}')
    else:
        device=torch.device('cpu' if args.device=='cpu' or not torch.cuda.is_available() else f'cuda:{args.device}')
        model,ckpt=load_model(args.weights or 'runs/counting/best.pt',device)
        with torch.inference_mode():
            for index,path in enumerate(paths):
                im=cv2.imread(str(path))
                if im is None:raise ValueError(f'Cannot read {path}')
                x=cv2.cvtColor(cv2.resize(im,(ckpt['size'],ckpt['size'])),cv2.COLOR_BGR2RGB)
                x=torch.from_numpy(x.transpose(2,0,1).copy()).unsqueeze(0).to(device).float()/255
                with torch.autocast(device_type=device.type,enabled=device.type=='cuda'):
                    prob=model(x).softmax(1)
                    if ckpt.get('tta',False):prob=(prob+model(x.flip(-1)).softmax(1))/2
                prob=prob.float().cpu().numpy();count=int(decode(prob,ckpt['decode'])[0])
                rows.append((str(path),count));details.append({'image':str(path),'count':count,'probabilities':prob[0].tolist()})
                canvas=cv2.resize(im,(288,288));canvas=cv2.copyMakeBorder(canvas,42,0,0,0,cv2.BORDER_CONSTANT,value=(25,25,25))
                cv2.putText(canvas,f'Apples: {count} (patch)',(10,28),cv2.FONT_HERSHEY_SIMPLEX,.7,(255,255,255),2)
                cv2.imwrite(str(out/f'{index:05d}_{path.stem}_count{count}.jpg'),canvas)
                print(f'{path.name}: {count}')
    with (out/'counts.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['image','predicted_count']);w.writerows(rows)
    save_json(out/'predictions.json',details)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source');p.add_argument('--mode',choices=['orchard','patch'],default='orchard')
    default_selection='results/optimization/selection.json' if Path('results/optimization/selection.json').is_file() else 'results/detection/selection.json'
    p.add_argument('--weights');p.add_argument('--selection',default=default_selection)
    p.add_argument('--device',default='0');p.add_argument('--out',default='predictions');predict(p.parse_args())

if __name__=='__main__':main()
