"""Reproduce exact-pixel counting integrity findings and exclusion policy on CPU.

Example: python -B -m apple_counter.audit_counting --data datasets --out results/audit
Existing output files are refused unless --overwrite is explicitly supplied. This
module never imports torch, evaluates a model, changes labels, or edits a dataset.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import time

import cv2
import numpy as np

SPLITS = ('train', 'val', 'officialtest')
REPORT_NAME = 'audit_counting_integrity.json'
POLICY_NAME = 'audit_counting_split_policy.json'


def decoded_pixel_sha256(image):
    """Hash exact OpenCV BGR pixels, including original HWC shape and dtype."""
    if image is None:
        raise ValueError('Cannot hash an unreadable image')
    header = (str(image.shape) + '|' + str(image.dtype) + '|').encode()
    return hashlib.sha256(header + image.tobytes()).hexdigest()


def _load_rows(data, split):
    if split == 'officialtest':
        base = data / 'test_data' / 'counting'
        label_path = base / 'ground_truth.json'
        # Object pairs preserve duplicate keys so they can be rejected, not hidden.
        pairs = json.loads(label_path.read_text(), object_pairs_hook=list)
    else:
        base = data / 'counting' / split
        label_path = base / f'{split}_ground_truth.txt'
        with label_path.open(newline='') as handle:
            pairs = [(row['Image'], row['count']) for row in csv.DictReader(handle)]
    rows = []
    seen = set()
    for name, raw_label in pairs:
        if not isinstance(name, str) or Path(name).name != name or '/' in name or '\\' in name:
            raise ValueError(f'Expected a basename in {label_path}: {name!r}')
        if name in seen:
            raise ValueError(f'Duplicate label name in {label_path}: {name}')
        seen.add(name)
        label = int(raw_label)
        if str(label) != str(raw_label).strip() or not 0 <= label <= 6:
            raise ValueError(f'Invalid count in {label_path}: {name}={raw_label!r}')
        rows.append((base / 'images' / name, label))
    if not rows:
        raise ValueError(f'Empty counting split: {label_path}')
    return base, label_path, rows


def _hash_summary(groups):
    duplicates = [{'sha256': digest, 'images': entries}
                  for digest, entries in groups.items() if len(entries) > 1]
    within = {s: {'duplicate_groups': 0, 'extra_images': 0, 'label_conflict_groups': 0}
              for s in SPLITS}
    cross = []
    for group in duplicates:
        entries = group['images']
        splits = {entry['split'] for entry in entries}
        if len(splits) > 1:
            cross.append(group)
        for split in splits:
            subset = [entry for entry in entries if entry['split'] == split]
            if len(subset) > 1:
                within[split]['duplicate_groups'] += 1
                within[split]['extra_images'] += len(subset) - 1
                within[split]['label_conflict_groups'] += int(len({entry['label'] for entry in subset}) > 1)
    pair_counts = {}
    for a, b in (('train', 'val'), ('train', 'officialtest'), ('val', 'officialtest')):
        pair_counts[f'{a}__{b}'] = sum(
            {a, b}.issubset({entry['split'] for entry in group['images']}) for group in cross)
    return {
        'n_unique_hashes': len(groups), 'n_duplicate_groups': len(duplicates),
        'within_split': within, 'cross_split_duplicate_groups': len(cross),
        'cross_split_group_counts': pair_counts, 'cross_split_duplicates': cross,
        'label_conflicting_duplicates': [group for group in duplicates
                                        if len({entry['label'] for entry in group['images']}) > 1],
        'within_split_duplicate_examples': [group for group in duplicates
                                            if len({entry['split'] for entry in group['images']}) == 1][:30],
    }


def build_policy(records, pixel_groups):
    """Deterministic exclusion/include names; never use predictions or scores."""
    reasons = {name: set() for name in (
        'train_matches_original_val', 'train_matches_original_test',
        'train_internal_label_conflict', 'val_matches_original_test',
        'test_original_train_or_val_overlap', 'test_internal_label_conflict',
        'test_duplicate_nonrepresentatives')}
    include = []
    conflict_hashes = overlap_hashes = 0
    for entries in pixel_groups.values():
        split_entries = {s: [entry for entry in entries if entry['split'] == s] for s in SPLITS}
        train, val, test = (split_entries[s] for s in SPLITS)
        if val:
            reasons['train_matches_original_val'].update(entry['image'] for entry in train)
        if test:
            reasons['train_matches_original_test'].update(entry['image'] for entry in train)
            reasons['val_matches_original_test'].update(entry['image'] for entry in val)
        if len({entry['label'] for entry in train}) > 1:
            reasons['train_internal_label_conflict'].update(entry['image'] for entry in train)
        if not test:
            continue
        conflicting = len({entry['label'] for entry in test}) > 1
        overlap = bool(train or val)
        if conflicting:
            conflict_hashes += 1
            reasons['test_internal_label_conflict'].update(entry['image'] for entry in test)
        if overlap:
            overlap_hashes += 1
            reasons['test_original_train_or_val_overlap'].update(entry['image'] for entry in test)
        if not conflicting and not overlap:
            names = sorted(entry['image'] for entry in test)
            include.append(names[0])
            reasons['test_duplicate_nonrepresentatives'].update(names[1:])
    train_exclude = (reasons['train_matches_original_val'] | reasons['train_matches_original_test']
                     | reasons['train_internal_label_conflict'])
    val_exclude = reasons['val_matches_original_test']
    include = sorted(include)
    test_names = {entry['image'] for entry in records['officialtest']}
    test_exclude = test_names - set(include)
    counts = {
        'train_original': len(records['train']), 'train_excluded': len(train_exclude),
        'train_retained': len(records['train']) - len(train_exclude),
        'train_exclusion_reasons_nonexclusive': {
            'matches_original_val': len(reasons['train_matches_original_val']),
            'matches_original_test': len(reasons['train_matches_original_test']),
            'internal_label_conflict': len(reasons['train_internal_label_conflict'])},
        'val_original': len(records['val']), 'val_excluded': len(val_exclude),
        'val_retained': len(records['val']) - len(val_exclude),
        'val_exclusion_reasons': {'matches_original_test': len(val_exclude)},
        'officialtest_original': len(test_names), 'officialtest_clean_retained': len(include),
        'officialtest_clean_excluded': len(test_exclude),
        'officialtest_exclusion_reasons_nonexclusive': {
            'original_train_or_val_overlap_images': len(reasons['test_original_train_or_val_overlap']),
            'internal_label_conflict_images': len(reasons['test_internal_label_conflict']),
            'deduplicated_other_eligible_images': len(reasons['test_duplicate_nonrepresentatives'])},
        'officialtest_conflicting_hash_groups': conflict_hashes,
        'officialtest_original_development_overlap_hash_groups': overlap_hashes,
        'officialtest_conflict_and_development_overlap_images': len(
            reasons['test_internal_label_conflict'] & reasons['test_original_train_or_val_overlap']),
    }
    include_set = set(include)
    histograms = {
        'train': dict(sorted(Counter(entry['label'] for entry in records['train']
                                    if entry['image'] not in train_exclude).items())),
        'val': dict(sorted(Counter(entry['label'] for entry in records['val']
                                  if entry['image'] not in val_exclude).items())),
        'officialtest_clean': dict(sorted(Counter(entry['label'] for entry in records['officialtest']
                                                 if entry['image'] in include_set).items())),
    }
    # Compare retained train/val with the FULL original test, not just clean test.
    for digest, entries in pixel_groups.items():
        retained = {entry['split'] for entry in entries
                    if entry['split'] == 'officialtest'
                    or (entry['split'] == 'train' and entry['image'] not in train_exclude)
                    or (entry['split'] == 'val' and entry['image'] not in val_exclude)}
        if len(retained) > 1:
            raise AssertionError(f'Policy left a cross-split duplicate: {digest}')
    return {
        'policy_id': 'counting-exact-pixel-hygiene-v1',
        'algorithm': {
            'pixel_hash': "OpenCV IMREAD_COLOR BGR; SHA256((str(shape)+'|'+str(dtype)+'|').encode()+pixels.tobytes()).",
            'train_exclude': 'Exclude all train hashes occurring in original val OR original test, plus all train members of train-internal label-conflicting hashes.',
            'val_exclude': 'Exclude val hashes occurring in original test only. Original train-val overlap is removed from train, preserving other validation images.',
            'test_clean_include': 'Exclude original train/val overlap and test-internal label conflicts; retain the lexicographically first filename per remaining test hash. Sort names.',
            'retained_duplicates': 'Other same-label duplicates within train or val remain. No relabeling, class balancing, predictions, or score-based selection.',
            'official_test_preservation': 'Keep full official test reporting distinct from the strict clean subset; do not modify original image or label files.',
            'limitations': 'Exact pixels only; source-frame independence and absence of transformed, recompressed, resized, overlapping or adjacent-frame duplicates are not established.',
        },
        'counts': counts, 'retained_label_histograms': histograms,
        'train_exclude': sorted(train_exclude), 'val_exclude': sorted(val_exclude),
        'test_clean_include': include, 'test_clean_exclude': sorted(test_exclude),
        'reason_names': {name: sorted(names) for name, names in reasons.items()},
        'verification': {
            'known_cross_split_duplicate_groups_after_train_val_filtering_against_full_original_test': 0,
            'test_clean_hashes_unique': True, 'all_output_name_lists_sorted': True,
            'all_output_names_found_in_original_labels': True, 'original_labels_unchanged': True,
        },
    }


def audit_counting(data, progress=None):
    """Read each labeled image once, sequentially, returning report and policy."""
    cv2.setNumThreads(1)
    data = Path(data)
    started = time.perf_counter()
    raw_groups, pixel_groups = defaultdict(list), defaultdict(list)
    records, split_info = {}, {}
    for split in SPLITS:
        base, label_path, rows = _load_rows(data, split)
        names = {path.name for path, _ in rows}
        actual_names = {path.name for path in (base / 'images').iterdir() if path.is_file()}
        missing = sorted(names - actual_names)
        if missing:
            raise FileNotFoundError(f'{split}: {len(missing)} missing images: {missing[:3]}')
        shapes, extensions, source_groups = Counter(), Counter(), Counter()
        source_frames = set()
        suffix_counts = Counter()
        total_bytes = 0
        records[split] = []
        for index, (path, label) in enumerate(rows, 1):
            content = path.read_bytes()
            total_bytes += len(content)
            image = cv2.imdecode(np.frombuffer(content, dtype=np.uint8), cv2.IMREAD_COLOR)
            if image is None:
                raise ValueError(f'Cannot decode {path}')
            entry = {'split': split, 'image': path.name, 'label': label}
            records[split].append(entry)
            raw_groups[hashlib.sha256(content).hexdigest()].append(entry)
            pixel_groups[decoded_pixel_sha256(image)].append(entry)
            shapes[str(tuple(image.shape))] += 1
            extensions[path.suffix.lower()] += 1
            match = re.match(r'(testset\d+)_(\d+)cluster_', path.name)
            if match:
                source_groups[match[1]] += 1
                source_frames.add((match[1], match[2]))
            match = re.search(r'_count(\d+)\.', path.name)
            if match:
                suffix_counts['files_with_suffix'] += 1
                suffix_counts['suffix_disagrees_with_label'] += int(int(match[1]) != label)
            if progress and index % 10000 == 0:
                progress(f'{split}: {index}/{len(rows)} images hashed')
        split_info[split] = {
            'label_file': str(label_path.relative_to(data)),
            'label_file_sha256': hashlib.sha256(label_path.read_bytes()).hexdigest(),
            'n_labels': len(rows), 'n_image_files': len(actual_names),
            'histogram': dict(sorted(Counter(label for _, label in rows).items())),
            'total_apples': sum(label for _, label in rows), 'duplicate_label_names': [],
            'missing_images': [], 'unlabeled_images': sorted(actual_names - names),
            'invalid_labels': [], 'unreadable_images': [], 'image_shapes_hwc': dict(shapes),
            'extensions': dict(extensions), 'total_bytes': total_bytes,
            'source_group_histogram': dict(source_groups), 'unique_named_source_frames': len(source_frames),
            'filename_count_suffix': dict(suffix_counts),
        }
        if progress:
            progress(f'{split}: complete ({len(rows)} images)')
    policy = build_policy(records, pixel_groups)
    report = {
        'scope': 'Integrity only; no model evaluation, training, label tuning or GPU. File-byte and decoded-pixel SHA256.',
        'data_root': str(data.resolve()), 'splits': split_info,
        'provenance': {
            'train_val': 'Sequential train/val image names and count labels do not preserve original source/frame identity.',
            'officialtest': 'Filename source/cluster tokens are retained. Filename count suffixes are not authoritative labels.',
            'limitation': 'Exact duplicate audit does not establish source-frame independence or absence of transformed/near duplicates.',
        },
        'file_sha256': _hash_summary(raw_groups), 'decoded_pixel_sha256': _hash_summary(pixel_groups),
        'elapsed_seconds': time.perf_counter() - started,
    }
    policy['inputs'] = {
        'data_root': str(data.resolve()),
        'original_label_sha256': {split: info['label_file_sha256'] for split, info in split_info.items()},
        'opencv_version': cv2.__version__, 'numpy_version': np.__version__,
    }
    return report, policy


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=Path('datasets'))
    parser.add_argument('--out', type=Path, default=Path('results/audit'))
    parser.add_argument('--overwrite', action='store_true', help='Explicitly allow replacement of existing audit outputs')
    args = parser.parse_args(argv)
    report_path, policy_path = args.out / REPORT_NAME, args.out / POLICY_NAME
    for path in (report_path, policy_path):
        if path.exists() and not args.overwrite:
            parser.error(f'Output exists: {path}; select another --out or explicitly pass --overwrite')
    report, policy = audit_counting(args.data, progress=lambda text: print(text, flush=True))
    report_text = json.dumps(report, indent=2, ensure_ascii=False)
    policy['created_utc'] = datetime.now(timezone.utc).isoformat()
    policy['inputs']['integrity_report'] = REPORT_NAME
    policy['inputs']['integrity_report_sha256'] = hashlib.sha256(report_text.encode('utf-8')).hexdigest()
    args.out.mkdir(parents=True, exist_ok=True)
    mode = 'w' if args.overwrite else 'x'
    # newline='' ensures the recorded SHA256 is identical to the UTF-8 file bytes on Windows.
    with report_path.open(mode, encoding='utf-8', newline='') as handle:
        handle.write(report_text)
    with policy_path.open(mode, encoding='utf-8', newline='') as handle:
        json.dump(policy, handle, indent=2, ensure_ascii=False)
    print(json.dumps(policy['counts'], indent=2), flush=True)
    print(f'Wrote {report_path} and {policy_path}', flush=True)


if __name__ == '__main__':
    main()
