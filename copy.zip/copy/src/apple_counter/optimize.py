"""Bounded, parent-group-safe detector optimization; no test-driven parameter search."""
from pathlib import Path
import argparse,json,time
import numpy as np
from .common import seed_everything,save_json,count_metrics
from .detection import (load_records,checkpoint_sha256,verify_selection_checkpoint,
                        validate_predictions,write_results)
from .tiled import run_tiled_predictions


def train(args):
    import torch
    from ultralytics import YOLO
    protocol=json.loads(Path(args.protocol).read_text())
    out=Path('runs/detector_s_tiled')
    if out.exists():raise FileExistsError('Bounded protocol refuses a second fit or overwriting an existing run')
    seed_everything(42)
    config=protocol['training'].copy()
    model=YOLO(config.pop('initial_weights'))
    for key in ['initialization','checkpoint']:config.pop(key)
    config['epochs']=config.pop('epochs_max')
    if args.device!='cpu':
        free,total=torch.cuda.mem_get_info()
        if free<3*1024**3:
            raise RuntimeError(f'Only {free/1024**3:.2f} GiB GPU memory free. Close unrelated GPU applications before training; no processes were stopped.')
    lock_dir=Path(args.out);lock_dir.mkdir(parents=True,exist_ok=True)
    lock_path=lock_dir/'protocol_lock.json'
    if lock_path.exists():raise FileExistsError('A training attempt was already locked; do not silently restart experiments')
    (lock_dir/'protocol_before_training.json').write_bytes(Path(args.protocol).read_bytes())
    save_json(lock_path,{'protocol_sha256':checkpoint_sha256(args.protocol),
                        'parent_manifest_sha256':checkpoint_sha256(protocol['split_manifest']),
                        'tile_manifest_sha256':checkpoint_sha256(Path(args.yaml).parent/'manifest.json')})
    model.train(data=str(Path(args.yaml).resolve()),device=args.device,workers=args.workers,
                project='runs',name='detector_s_tiled',exist_ok=False,
                deterministic=True,amp=True,cache=False,plots=True,max_det=500,
                **config)


def group_indices(records):
    groups={}
    for i,(p,gt) in enumerate(records):groups.setdefault(p.stem.split('_image')[0],[]).append(i)
    if len(groups)!=2:raise ValueError('Frozen protocol expects exactly two validation sequences')
    return {g:np.asarray(idx) for g,idx in groups.items()}


def score_threshold(records,predictions,conf):
    validate_predictions(records,predictions)
    y=np.asarray([len(gt) for p,gt in records])
    p=np.asarray([int((np.asarray(pr['scores'],dtype=float)>=conf).sum()) for pr in predictions])
    groups=group_indices(records);by_group={g:count_metrics(y[idx],p[idx]) for g,idx in groups.items()}
    return {'confidence':float(conf),'aggregate':count_metrics(y,p),'per_sequence':by_group,
            'sequence_macro_mae':float(np.mean([m['mae'] for m in by_group.values()]))}


def calibrate(records,predictions,grid):
    validate_predictions(records,predictions)
    trials=[score_threshold(records,predictions,c) for c in grid]
    selected=min(trials,key=lambda t:(t['sequence_macro_mae'],t['aggregate']['rmse'],-t['confidence']))
    groups=group_indices(records);names=sorted(groups);folds=[];cross_by_group={}
    y=np.asarray([len(gt) for p,gt in records]);cross_predictions=np.empty(len(y),dtype=int)
    for fit,held in [names,names[::-1]]:
        best=min(trials,key=lambda t:(t['per_sequence'][fit]['mae'],t['per_sequence'][fit]['rmse'],-t['confidence']))
        folds.append({'fit_sequence':fit,'held_sequence':held,'confidence':best['confidence'],
                      'held_mae':best['per_sequence'][held]['mae']})
        cross_by_group[held]=best['per_sequence'][held]
        idx=groups[held]
        cross_predictions[idx]=[int((np.asarray(predictions[i]['scores'],dtype=float)>=best['confidence']).sum()) for i in idx]
    return {'chosen':selected,'trials':trials,'crossfit_folds':folds,
            'crossfit_per_sequence':cross_by_group,'crossfit_aggregate':count_metrics(y,cross_predictions),
            'crossfit_macro_mae':float(np.mean([x['held_mae'] for x in folds]))}


def promotion_reasons(candidate,baseline,baseline_crossfit):
    failures=[];cal=candidate['calibration'];c=cal['chosen']
    if cal['crossfit_macro_mae']>baseline_crossfit['crossfit_macro_mae']*.9:failures.append('crossfit macro MAE improvement below10%')
    if cal['crossfit_aggregate']['mae']>baseline_crossfit['crossfit_aggregate']['mae']*.9:failures.append('crossfit aggregate MAE improvement below10%')
    if cal['crossfit_aggregate']['rmse']>baseline_crossfit['crossfit_aggregate']['rmse']:failures.append('crossfit RMSE regression')
    for group,metric in baseline_crossfit['crossfit_per_sequence'].items():
        if cal['crossfit_per_sequence'][group]['mae']>metric['mae']*.95:failures.append(f'crossfit sequence improvement below5%: {group}')
    if c['aggregate']['mae']>baseline['aggregate']['mae']*.9:failures.append('deployment aggregate MAE improvement below10%')
    if c['aggregate']['rmse']>baseline['aggregate']['rmse']:failures.append('deployment RMSE regression')
    for group,metric in baseline['per_sequence'].items():
        if c['per_sequence'][group]['mae']>metric['mae']:failures.append(f'deployment sequence regression: {group}')
    return failures


def candidate_config(protocol,candidate):
    return {**protocol['fixed_inference'],**candidate,'deployment_weights':candidate['weights'],
            'weights_sha256':checkpoint_sha256(candidate['weights']),'confidence':.35}


def validate(args):
    from ultralytics import YOLO
    seed_everything(42)
    protocol=json.loads(Path(args.protocol).read_text());out=Path(args.out)
    if (out/'selection.json').exists():raise FileExistsError('Frozen selection exists; no silent retuning')
    lock=json.loads((out/'protocol_lock.json').read_text())
    if checkpoint_sha256(args.protocol)!=lock['protocol_sha256']:raise ValueError('Protocol changed after training started')
    if checkpoint_sha256(protocol['split_manifest'])!=lock['parent_manifest_sha256']:raise ValueError('Parent split manifest changed')
    if checkpoint_sha256(Path(args.yaml).parent/'manifest.json')!=lock['tile_manifest_sha256']:raise ValueError('Tile manifest changed')
    records=load_records(args.data,args.prepared,'val');summaries=[]
    for candidate in protocol['candidates']:
        cfg=candidate_config(protocol,candidate);folder=out/candidate['id'];folder.mkdir(parents=True,exist_ok=True)
        cache=folder/'val_detections.json';metadata=folder/'cache_config.json'
        if cache.exists() and metadata.exists() and json.loads(metadata.read_text())==cfg:
            predictions=json.loads(cache.read_text());seconds=0.
        elif candidate['id']=='baseline_full':
            original=json.loads(Path('results/detection/selection.json').read_text())
            verify_selection_checkpoint(original,cfg['weights'])
            if original['imgsz']!=960 or original['iou']!=.6:raise ValueError('Original baseline config changed')
            predictions=json.loads(Path('results/detection/val_detections.json').read_text());seconds=0.
            save_json(cache,predictions);save_json(metadata,cfg)
        else:
            model=YOLO(cfg['weights']);predictions,seconds=run_tiled_predictions(model,records,cfg,args.device)
            save_json(cache,predictions);save_json(metadata,cfg);del model
        calibration=calibrate(records,predictions,protocol['confidence_grid'])
        cfg['confidence']=calibration['chosen']['confidence']
        cfg['selected_on']='Two validation sequences, sequence-macro count MAE; no test inputs'
        save_json(folder/'selection.json',cfg);save_json(folder/'calibration.json',calibration)
        write_results(folder,'val',records,predictions,cfg,seconds)
        summaries.append({'id':candidate['id'],'configuration':cfg,'calibration':calibration,'inference_seconds':seconds})
        print(candidate['id'],'macroMAE',calibration['chosen']['sequence_macro_mae'],'crossfit',calibration['crossfit_macro_mae'],flush=True)
    baseline_predictions=json.loads((out/'baseline_full/val_detections.json').read_text())
    baseline=score_threshold(records,baseline_predictions,.35)
    baseline_crossfit=summaries[0]['calibration'];eligible=[]
    for item in summaries[1:]:
        item['promotion_failures']=promotion_reasons(item,baseline,baseline_crossfit)
        if not item['promotion_failures']:eligible.append(item)
    if eligible:
        winner=min(eligible,key=lambda x:(x['calibration']['crossfit_macro_mae'],x['calibration']['crossfit_aggregate']['rmse'],x['configuration']['inference_mode']=='tiled'))
        selection=winner['configuration'].copy();selection['promoted']=True
    else:
        selection=candidate_config(protocol,protocol['candidates'][0]);selection['confidence']=.35;selection['promoted']=False
    selection['selection_rule']='Frozen optimization_protocol.json; only validation compared'
    selection['protocol_sha256']=checkpoint_sha256(args.protocol)
    save_json(out/'comparison_validation.json',{'baseline_frozen':baseline,'baseline_crossfit':baseline_crossfit,'candidates':summaries,'chosen':selection['id']})
    save_json(out/'selection.json',selection)
    print('FROZEN SELECTION',json.dumps(selection,indent=2),flush=True)


def evaluate(args):
    from ultralytics import YOLO
    seed_everything(42)
    out=Path(args.out);selection=json.loads((out/'selection.json').read_text())
    verify_selection_checkpoint(selection,selection['weights'])
    if checkpoint_sha256(args.protocol)!=selection['protocol_sha256']:raise ValueError('Protocol changed after validation selection')
    # Evaluate promoted solution. If no promotion, evaluate predeclared s_tiled once as experimental.
    configurations=[selection]
    experimental=json.loads((out/'s_tiled/selection.json').read_text())
    if selection['id']!='s_tiled':configurations.append(experimental)
    for cfg in configurations:
        verify_selection_checkpoint(cfg,cfg['weights']);folder=out/'evaluation'/cfg['id'];folder.mkdir(parents=True,exist_ok=True)
        model=YOLO(cfg['weights'])
        for split in ['official_test','test']:
            if (folder/f'{split}_metrics.json').exists():raise FileExistsError('Refuse repeated test evaluation')
            records=load_records(args.data,args.prepared,split)
            predictions,seconds=run_tiled_predictions(model,records,cfg,args.device)
            save_json(folder/f'{split}_detections.json',predictions)
            metrics=write_results(folder,split,records,predictions,cfg,seconds)
            print(cfg['id'],split,json.dumps(metrics),flush=True)
        del model
    save_json(out/'evaluation/frozen_test_access.json',{'selection':selection,'evaluated_ids':[c['id'] for c in configurations],
              'warning':'These are previously inspected reused comparison sets, not a new blind test. No post-test retuning.'})


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['train','validate','evaluate'])
    p.add_argument('--protocol',default='optimization_protocol.json');p.add_argument('--yaml',default='datasets/yolo_tiled/data.yaml')
    p.add_argument('--data',default='datasets');p.add_argument('--prepared',default='datasets/yolo');p.add_argument('--out',default='results/optimization')
    p.add_argument('--device',default='0');p.add_argument('--workers',type=int,default=4)
    args=p.parse_args();{'train':train,'validate':validate,'evaluate':evaluate}[args.command](args)

if __name__=='__main__':main()
