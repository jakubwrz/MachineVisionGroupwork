"""Generate evidence plots from stored predictions; does not alter model selection."""
from pathlib import Path
import argparse,csv,json
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def read_csv(path):
    with Path(path).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',default='.');args=ap.parse_args();root=Path(args.root)
    out=root/'results/figures';out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.size':11,'figure.dpi':140,'savefig.bbox':'tight'})
    patch=root/'results/counting/test_predictions.csv'
    if patch.exists():
        rows=read_csv(patch);y=np.array([int(r['true_count']) for r in rows]);p=np.array([int(r['predicted_count']) for r in rows])
        cm=np.zeros((7,7),int);np.add.at(cm,(y,p),1)
        fig,ax=plt.subplots(figsize=(6,5));im=ax.imshow(cm,cmap='Blues');fig.colorbar(im,ax=ax)
        for i in range(7):
            for j in range(7):ax.text(j,i,str(cm[i,j]),ha='center',va='center',color='white' if cm[i,j]>cm.max()*.5 else 'black')
        ax.set(xlabel='Predicted count',ylabel='Ground-truth count',title='Patch counting: official test',xticks=range(7),yticks=range(7))
        fig.savefig(out/'patch_confusion.png');plt.close(fig)
        # Three examples per true count: first, middle, last by filename.
        canvas=Image.new('RGB',(7*180,3*200),'#f2f5f8');draw=ImageDraw.Draw(canvas)
        font=ImageFont.truetype('DejaVuSans.ttf',14) if False else ImageFont.load_default(size=14)
        for c in range(7):
            ids=np.where(y==c)[0]
            if not len(ids):continue
            for j,i in enumerate(ids[np.linspace(0,len(ids)-1,min(3,len(ids)),dtype=int)]):
                image=Image.open(root/'datasets/test_data/counting/images'/rows[i]['image']).convert('RGB');image.thumbnail((172,164))
                x=c*180+4;yy=j*200+4;canvas.paste(image,(x,yy));draw.text((x,yy+167),f'GT {y[i]} / Pred {p[i]}',fill='black',font=font)
        canvas.save(out/'patch_examples.jpg')
        metrics=json.loads((root/'results/counting/test_metrics.json').read_text())
        if (root/'results/baseline/test_metrics.json').exists():
            baseline=json.loads((root/'results/baseline/test_metrics.json').read_text())
            vals=[baseline['constant_median']['mae'],baseline['hsv']['mae'],metrics['mae']]
            fig,ax=plt.subplots(figsize=(7,4));bars=ax.bar(['Constant median','HSV + morphology','ResNet18'],vals,color=['#a0a9b3','#e7a641','#207e9d'])
            ax.bar_label(bars,fmt='%.3f');ax.set(ylabel='MAE (apples / patch)',title='Patch counting: official test comparison',ylim=(0,max(vals)*1.2))
            fig.savefig(out/'patch_comparison.png');plt.close(fig)
    hist=root/'runs/counting/history.json'
    if hist.exists():
        h=json.loads(hist.read_text());fig,ax=plt.subplots(figsize=(7,4))
        ax.plot([r['epoch'] for r in h],[r['val']['mae'] for r in h],'-o',label='Validation MAE')
        ax.plot([r['epoch'] for r in h],[r['loss'] for r in h],'-',label='Training loss (CE + 0.15 Huber)')
        ax.set(xlabel='Epoch',title='Patch model learning curves');ax.legend();ax.grid(alpha=.2);fig.savefig(out/'patch_learning.png');plt.close(fig)
    det=root/'results/detection/official_test_predictions.csv'
    if det.exists():
        rows=read_csv(det);y=np.array([int(r['true_count']) for r in rows]);p=np.array([int(r['predicted_count']) for r in rows])
        fig,axs=plt.subplots(1,2,figsize=(10,4))
        axs[0].scatter(y,p,s=14,alpha=.5,color='#207e9d');hi=max(y.max(),p.max())+5;axs[0].plot([0,hi],[0,hi],'--',color='gray')
        axs[0].set(xlabel='Ground-truth apples',ylabel='Predicted apples',title='Orchard official test: 331 images')
        axs[1].hist(p-y,bins=25,color='#207e9d');axs[1].axvline(0,color='gray',linestyle='--')
        axs[1].set(xlabel='Prediction - ground truth',ylabel='Images',title='Count error distribution')
        fig.tight_layout();fig.savefig(out/'orchard_errors.png');plt.close(fig)
        images=sorted((root/'results/detection/official_test_examples').glob('*.jpg'))
        canvas=Image.new('RGB',(3*360,2*640),'white')
        for i,path in enumerate(images[:6]):
            image=Image.open(path);image.thumbnail((360,640));canvas.paste(image,((i%3)*360,(i//3)*640))
        canvas.save(out/'orchard_examples.jpg')
    print('Figures saved:',out)

if __name__=='__main__':main()
