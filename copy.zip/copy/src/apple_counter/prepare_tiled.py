"""Prepare full + tiled train/validation data without reading any held-out images.

The frozen parent manifest is authoritative: no repartitioning occurs. Only its
train/val image-mask pairs are opened; test records are used as metadata solely
for split-safety checks. Tile labels come from cropped ORIGINAL instance-ID masks.
Final model/threshold selection must use the original full-image validation set,
not the repeated/overlapping samples in this training-time validation dataset.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from numbers import Integral, Real
from pathlib import Path

import numpy as np
from PIL import Image

from .prepare_detection import instance_boxes, materialize, sha256


def tile_windows(width: int, height: int, tile_size: int = 720,
                 overlap: float = .22) -> list[tuple[int, int, int, int]]:
    """Return row-major, de-duplicated, half-open pixel windows.

    Return [(0,0,width,height)] if BOTH dimensions fit so inference always covers
    the input. Otherwise each axis spans min(dimension, tile_size), with
    stride max(1, floor(tile_size * (1-overlap))) and the final start snapped to
    the far edge. Thus 720x1280 -> [(0,0,720,720), (0,560,720,1280)]. Narrow images
    produce bounded rectangular windows; no padding/resizing or content loss.
    Edge snapping can make actual overlap greater than the requested minimum.
    """
    for name, value in [('width', width), ('height', height), ('tile_size', tile_size)]:
        if isinstance(value, bool) or not isinstance(value, Integral) or value <= 0:
            raise ValueError(f'{name} must be a positive integer')
    if isinstance(overlap, bool) or not isinstance(overlap, Real) or not math.isfinite(overlap) or not 0 <= overlap < 1:
        raise ValueError('overlap must be finite and in [0,1)')
    width, height, tile_size = int(width), int(height), int(tile_size)
    if width <= tile_size and height <= tile_size:
        return [(0, 0, width, height)]
    stride = max(1, int(math.floor(tile_size * (1 - float(overlap)))))

    def starts(length: int) -> list[int]:
        end = max(0, length - tile_size)
        values = list(range(0, end + 1, stride))
        if values[-1] != end:
            values.append(end)
        return values

    return [(x, y, min(x + tile_size, width), min(y + tile_size, height))
            for y in starts(height) for x in starts(width)]


def _source_path(record: dict, key: str, prepared: Path) -> Path:
    path = Path(record[key])
    return (path if path.is_absolute() else prepared / path).resolve()


def _validate_parent_manifest(manifest: dict, prepared: Path, out: Path) -> list[dict]:
    """Validate all split METADATA, but never stat/open a held-out image or mask."""
    records = manifest.get('records')
    if not isinstance(records, list) or not records:
        raise ValueError('Parent manifest must contain nonempty records')
    assignments = manifest.get('group_assignments')
    if not isinstance(assignments, dict):
        raise ValueError('Parent group_assignments are required')
    seen_names, seen_stems, groups, source_splits, hash_splits = set(), set(), defaultdict(set), defaultdict(set), defaultdict(set)
    chosen = []
    for record in records:
        split = record.get('split')
        if split not in ('train', 'val', 'test'):
            raise ValueError(f'Unsupported parent split: {split!r}')
        name, group = record.get('filename'), record.get('group')
        if not isinstance(name, str) or not name or Path(name).name != name or '/' in name or '\\' in name:
            raise ValueError(f'Expected a parent basename, got {name!r}')
        if name in seen_names or Path(name).stem in seen_stems:
            raise ValueError(f'Duplicate parent filename/stem: {name}')
        seen_names.add(name); seen_stems.add(Path(name).stem)
        if not isinstance(group, str) or assignments.get(group) != split:
            raise ValueError(f'Parent group assignment mismatch: {name}')
        groups[group].add(split)
        # Compare metadata path strings without resolving or opening TEST paths.
        for key in ('source_image', 'source_mask'):
            value = record.get(key)
            if not isinstance(value, str) or not value:
                raise ValueError(f'Missing {key} in parent {name}')
            source_splits[(key, value.replace('\\', '/').casefold())].add(split)
        for key in ('image_sha256', 'mask_sha256'):
            value = record.get(key)
            if not isinstance(value, str) or len(value) != 64 or any(c not in '0123456789abcdef' for c in value.lower()):
                raise ValueError(f'Missing/invalid parent {key}: {name}')
        hash_splits[record['image_sha256'].lower()].add(split)
        if split not in ('train', 'val'):
            continue  # No image/mask path resolution, stat, hashing or decoding for test.
        for key in ('source_image', 'source_mask'):
            path = _source_path(record, key, prepared)
            if path == out or out in path.parents or path in out.parents:
                raise ValueError('Output must not contain/overwrite source data')
        chosen.append(record)
    if any(len(s) > 1 for s in groups.values()):
        raise ValueError('Parent group crosses split boundaries')
    if any(len(s) > 1 for s in source_splits.values()) or any(len(s) > 1 for s in hash_splits.values()):
        raise ValueError('Parent image identity crosses splits; refuse to weaken frozen split safety')
    if not all(any(r['split'] == split for r in chosen) for split in ('train', 'val')):
        raise ValueError('Nonempty train and val parent splits are required')
    for split in ('train', 'val'):
        expected = manifest.get('summary', {}).get(split, {}).get('images')
        if expected is not None and expected != sum(r['split'] == split for r in chosen):
            raise ValueError(f'Parent summary count mismatch for {split}')
    return sorted(chosen, key=lambda r: (r['split'], r['filename']))


def _write_labels(path: Path, instances: list[dict], width: int, height: int) -> None:
    lines = []
    for instance in instances:
        x1, y1, x2, y2 = instance['xyxy']
        values = ((x1 + x2) / (2 * width), (y1 + y2) / (2 * height),
                  (x2 - x1) / width, (y2 - y1) / height)
        lines.append('0 ' + ' '.join(f'{v:.10f}' for v in values))
    with path.open('x', encoding='utf-8') as stream:
        stream.write('\n'.join(lines) + ('\n' if lines else ''))


def prepare(prepared: Path = Path('datasets/yolo'), out: Path = Path('datasets/yolo_tiled'),
            tile_size: int = 720, overlap: float = .22, full: bool = True) -> dict:
    """Write a new dataset once; manifests and source content are never overwritten."""
    # Validate geometry even before loading metadata/creating any output.
    tile_windows(1, 1, tile_size, overlap)
    if not isinstance(full, bool):
        raise ValueError('full must be bool')
    prepared, out = Path(prepared).resolve(), Path(out).resolve()
    if prepared == out or prepared in out.parents or out in prepared.parents:
        raise ValueError('Prepared source and output must be separate, nonnested trees')
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise FileExistsError(f'Output must be absent or empty: {out}')
    source_manifest = prepared / 'manifest.json'
    original_bytes = source_manifest.read_bytes()
    parent = json.loads(original_bytes)
    parent_sha = hashlib.sha256(original_bytes).hexdigest()
    parents = _validate_parent_manifest(parent, prepared, out)
    for split in ('train', 'val'):
        (out / 'images' / split).mkdir(parents=True, exist_ok=True)
        (out / 'labels' / split).mkdir(parents=True, exist_ok=True)
    records = []
    for number, source in enumerate(parents, 1):
        split, name = source['split'], source['filename']
        image_path = _source_path(source, 'source_image', prepared)
        mask_path = _source_path(source, 'source_mask', prepared)
        image_sha, mask_sha = sha256(image_path), sha256(mask_path)
        if image_sha != source['image_sha256'] or mask_sha != source['mask_sha256']:
            raise ValueError(f'Parent source changed since frozen manifest: {name}')
        with Image.open(image_path) as opened:
            image = opened.convert('RGB')
        with Image.open(mask_path) as opened:
            mask = np.array(opened)  # Preserve palette-index/uint16 IDs, never RGB/binary convert.
        width, height = image.size
        if (width, height) != (source['width'], source['height']) or mask.shape != (height, width):
            raise ValueError(f'Parent image/mask dimensions disagree: {name}')
        original_instances = instance_boxes(mask)
        if len(original_instances) != source['count']:
            raise ValueError(f'Parent count disagrees with instance IDs: {name}')
        if 'instances' in source and original_instances != source['instances']:
            raise ValueError(f'Parent instance geometry changed: {name}')
        windows = [('full', None, (0, 0, width, height))] if full else []
        windows += [('tile', i, window) for i, window in enumerate(tile_windows(width, height, tile_size, overlap))
                    if not (full and window == (0, 0, width, height))]
        for kind, index, window in windows:
            x1, y1, x2, y2 = window
            crop_width, crop_height = x2 - x1, y2 - y1
            instances = original_instances if kind == 'full' else instance_boxes(mask[y1:y2, x1:x2])
            output_name = f'{Path(name).stem}__full{image_path.suffix.lower()}' if kind == 'full' else f'{Path(name).stem}__tile_{index:03d}.png'
            relative_image = Path('images') / split / output_name
            relative_label = Path('labels') / split / f'{Path(output_name).stem}.txt'
            if kind == 'full':
                image_mode = materialize(image_path, out / relative_image, 'auto')
                output_sha = image_sha
            else:
                image.crop(window).save(out / relative_image, format='PNG')
                image_mode = 'generated_png'
                output_sha = sha256(out / relative_image)
            _write_labels(out / relative_label, instances, crop_width, crop_height)
            records.append({'filename': output_name, 'image': relative_image.as_posix(),
                            'label': relative_label.as_posix(), 'kind': kind, 'tile_index': index,
                            'parentname': name, 'parent_filename': name, 'split': split,
                            'group': source['group'], 'date': source.get('date'),
                            'window_xyxy': list(window), 'width': crop_width, 'height': crop_height,
                            'parent_width': width, 'parent_height': height,
                            'count': len(instances), 'instances': instances,
                            'image_sha256': output_sha, 'label_sha256': sha256(out / relative_label),
                            'parent_image_sha256': image_sha, 'parent_mask_sha256': mask_sha,
                            'materialization': image_mode})
        if number % 100 == 0 or number == len(parents):
            print(f'Prepared {number}/{len(parents)} train/val parents; {len(records)} samples', flush=True)
    # Detect concurrent metadata edits before publishing the immutable provenance snapshot.
    if hashlib.sha256(source_manifest.read_bytes()).hexdigest() != parent_sha:
        raise ValueError('Parent manifest changed during preparation; refusing to publish')
    summary = {}
    for split in ('train', 'val'):
        items = [r for r in records if r['split'] == split]
        summary[split] = {'parents': sum(r['split'] == split for r in parents), 'images': len(items),
                          'full_images': sum(r['kind'] == 'full' for r in items),
                          'tiles': sum(r['kind'] == 'tile' for r in items),
                          'instances_including_overlap': sum(r['count'] for r in items),
                          'full_instances': sum(r['count'] for r in items if r['kind'] == 'full'),
                          'tile_instances_including_overlap': sum(r['count'] for r in items if r['kind'] == 'tile'),
                          'groups': sorted({r['group'] for r in items})}
    warnings = ['Only frozen parent train/val images and original instance masks were read; no test image/mask was opened.',
                'No random split: every full/tile sample inherits the parent split and group.',
                'Overlapping samples repeat apple instances; summed sample counts are not unique orchard counts.',
                'Use the original full-image validation set for final tiled-inference model/threshold selection; tiled val mAP is training-time monitoring only.',
                'Hardlinked full images share source bytes; never edit output images in place.',
                'Manifest is write-once through this API, SHA256-sealed, and never overwritten; OS-level tampering is detectable, not prevented.']
    manifest = {'version': 1, 'dataset_kind': 'frozen_split_full_and_mask_derived_tiles',
                'parent_manifest': str(source_manifest), 'parent_manifest_sha256': parent_sha,
                'output_root': str(out), 'tile_size': int(tile_size), 'overlap': float(overlap),
                'include_full': full, 'box_convention': 'xyxy half-open pixel edges; crop IDs before computing boxes',
                'grid_convention': 'row-major; stride=max(1,floor(tile_size*(1-overlap))); far edge snapped; small input has full window, deduplicated against full branch',
                'classes': {'0': 'apple'},
                'parent_group_assignments': parent['group_assignments'],
                'included_parent_splits': ['train', 'val'], 'excluded_parent_splits': ['test'],
                'summary': summary, 'warnings': warnings, 'records': records}
    data = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
    with (out / 'manifest.json').open('xb') as stream:
        stream.write(data)
    with (out / 'manifest.sha256').open('x', encoding='utf-8') as stream:
        stream.write(hashlib.sha256(data).hexdigest() + '  manifest.json\n')
    with (out / 'summary.json').open('x', encoding='utf-8') as stream:
        json.dump({'splits': summary, 'warnings': warnings}, stream, indent=2)
    with (out / 'data.yaml').open('x', encoding='utf-8') as stream:
        stream.write('# Frozen train/val parents only. No test split is exposed.\n'
                     f'path: {json.dumps(out.as_posix())}\ntrain: images/train\nval: images/val\nnc: 1\nnames:\n  0: apple\n')
    return manifest


def _boolean(value: str) -> bool:
    if value.lower() in ('true', '1', 'yes'):
        return True
    if value.lower() in ('false', '0', 'no'):
        return False
    raise argparse.ArgumentTypeError('Expected true or false')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepared', type=Path, default=Path('datasets/yolo'))
    parser.add_argument('--out', type=Path, default=Path('datasets/yolo_tiled'))
    parser.add_argument('--tile-size', type=int, default=720)
    parser.add_argument('--overlap', type=float, default=.22)
    parser.add_argument('--full', type=_boolean, default=True)
    args = parser.parse_args()
    result = prepare(**vars(args))
    print(json.dumps({'output': str(args.out.resolve()), 'summary': result['summary'], 'warnings': result['warnings']}, indent=2))


if __name__ == '__main__':
    main()
