"""Prepare sequence-disjoint YOLO apple detection data from labeled instance masks.

Example (no training and no official-test access):
  python -m apple_counter.prepare_detection --root datasets/detection --out prepared/detection

Only <root>/train/{images,masks} is read. The YAML test split is a held-out
INTERNAL subset, never the official dataset/test or test_data. Default grouping
keeps complete YYYYMMDD_HHMMSS captures together. This prevents same-sequence
frame leakage, NOT proven orchard/tree/date independence. There are only two
capture dates in this dataset; a three-way date-disjoint split is impossible.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shutil

import numpy as np
from PIL import Image

SPLITS = ("train", "val", "test")
NAME_RE = re.compile(r"^(?P<date>\d{8})_(?P<time>\d{6})_image(?P<frame>\d+)$")


def parse_group(filename: str, group_by: str = "sequence") -> tuple[str, str, int]:
    match = NAME_RE.fullmatch(Path(filename).stem)
    if not match:
        raise ValueError(f"Unrecognized capture filename, cannot safely group: {filename}")
    date = match["date"]
    sequence = f"{date}_{match['time']}"
    if group_by not in ("sequence", "date"):
        raise ValueError(f"Unknown grouping mode: {group_by}")
    return (sequence if group_by == "sequence" else date), date, int(match["frame"])


def instance_boxes(mask: np.ndarray) -> list[dict]:
    """One enclosing half-open xyxy box per nonzero ID, including disconnected pixels.

    Do not binarize, connected-component split, interpolate IDs, or use max(ID)
    as the count. All annotated IDs are kept, including one-pixel instances.
    """
    if mask.ndim != 2 or not np.issubdtype(mask.dtype, np.integer):
        raise ValueError(f"Expected 2D integer instance IDs; got {mask.shape}/{mask.dtype}")
    if np.any(mask < 0):
        raise ValueError("Negative instance IDs are unsupported")
    ys, xs = np.nonzero(mask)
    if not len(xs):
        return []
    ids, inverse, areas = np.unique(mask[ys, xs], return_inverse=True, return_counts=True)
    height, width = mask.shape
    x1 = np.full(len(ids), width, dtype=np.int64)
    y1 = np.full(len(ids), height, dtype=np.int64)
    x2 = np.zeros(len(ids), dtype=np.int64)
    y2 = np.zeros(len(ids), dtype=np.int64)
    np.minimum.at(x1, inverse, xs)
    np.minimum.at(y1, inverse, ys)
    np.maximum.at(x2, inverse, xs + 1)
    np.maximum.at(y2, inverse, ys + 1)
    return [{"instance_id": int(ids[i]), "xyxy": [int(x1[i]), int(y1[i]), int(x2[i]), int(y2[i])],
             "area_pixels": int(areas[i])} for i in range(len(ids))]


def assign_groups(group_sizes: dict[str, int], seed: int = 42,
                  val_fraction: float = .15, test_fraction: float = .15) -> dict[str, str]:
    """Seeded group assignment balancing image counts, without inspecting labels.

    Reserve approximately the requested fractions of *groups* for val/test,
    at least one each, and choose the closest image fractions among 4096
    seeded permutations. Group indivisibility means fractions are approximate.
    """
    if not (0 < val_fraction < 1 and 0 < test_fraction < 1 and val_fraction + test_fraction < 1):
        raise ValueError("val/test fractions must be positive and sum to less than one")
    groups = sorted(group_sizes)
    n = len(groups)
    if n < 3:
        raise ValueError(f"Need >=3 independent groups for train/val/test, found {n}. "
                         "Do not silently weaken date grouping; choose sequence grouping explicitly.")
    if any(size <= 0 for size in group_sizes.values()):
        raise ValueError("Every group must contain an image")
    nv = max(1, int(n * val_fraction + .5))
    nt = max(1, int(n * test_fraction + .5))
    while nv + nt >= n:
        if nv >= nt and nv > 1:
            nv -= 1
        elif nt > 1:
            nt -= 1
        else:
            raise ValueError("Cannot allocate nonempty train, val and test groups")
    target = np.array([1 - val_fraction - test_fraction, val_fraction, test_fraction])
    total = sum(group_sizes.values())
    rng = random.Random(seed)
    best, best_score = None, float("inf")
    for _ in range(4096):
        shuffled = groups.copy()
        rng.shuffle(shuffled)
        assignment = {g: ("val" if i < nv else "test" if i < nv + nt else "train")
                      for i, g in enumerate(shuffled)}
        actual = np.array([sum(group_sizes[g] for g in groups if assignment[g] == split)
                           for split in SPLITS]) / total
        score = float(np.sum((actual - target) ** 2))
        if score < best_score - 1e-15:
            best, best_score = assignment, score
    return dict(sorted(best.items()))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def materialize(source: Path, target: Path, mode: str) -> str:
    if mode == "copy":
        shutil.copy2(source, target)
        return "copy"
    if mode == "symlink":
        target.symlink_to(source.resolve())
        return "symlink"
    try:
        os.link(source, target)
        return "hardlink"
    except OSError:
        if mode == "hardlink":
            raise
        shutil.copy2(source, target)
        return "copy"


def prepare(root: Path, out: Path, seed: int = 42, val_fraction: float = .15,
            test_fraction: float = .15, group_by: str = "sequence", image_mode: str = "auto") -> dict:
    root, out = Path(root).resolve(), Path(out).resolve()
    if image_mode not in ("auto", "copy", "hardlink", "symlink"):
        raise ValueError(f"Unknown image mode: {image_mode}")
    if root == out or root in out.parents or out in root.parents:
        raise ValueError("Output and source trees must be separate, not nested")
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f"Output must be absent or empty to avoid stale labels: {out}")
    image_dir, mask_dir = root / "train" / "images", root / "train" / "masks"
    images = {p.stem: p for p in sorted(image_dir.glob("*.png"))}
    masks = {p.stem: p for p in sorted(mask_dir.glob("*.png"))}
    if not images or images.keys() != masks.keys():
        raise ValueError(f"Expected nonempty exact image/mask pairing: images={len(images)}, masks={len(masks)}, "
                         f"missing masks={sorted(images.keys()-masks.keys())[:10]}, "
                         f"missing images={sorted(masks.keys()-images.keys())[:10]}")
    groups = {stem: parse_group(path.name, group_by) for stem, path in images.items()}
    group_sizes = dict(Counter(group[0] for group in groups.values()))
    assignment = assign_groups(group_sizes, seed, val_fraction, test_fraction)
    records, hash_splits = [], defaultdict(set)
    # Validate everything before creating outputs. No official-test paths are opened.
    for stem, source in images.items():
        group, date, frame = groups[stem]
        with Image.open(source) as image:
            width, height = image.size
        with Image.open(masks[stem]) as mask_image:
            mask = np.array(mask_image)  # Preserve palette/integer IDs, never convert to binary.
        if mask.shape != (height, width):
            raise ValueError(f"Image/mask dimension mismatch: {source.name}: {mask.shape} vs {(height, width)}")
        boxes = instance_boxes(mask)
        digest = sha256(source)
        split = assignment[group]
        hash_splits[digest].add(split)
        records.append({"filename": source.name, "source_image": str(source), "source_mask": str(masks[stem]),
                        "image_sha256": digest, "mask_sha256": sha256(masks[stem]),
                        "group": group, "date": date, "frame": frame, "split": split,
                        "width": width, "height": height, "count": len(boxes), "instances": boxes})
    if any(len(splits) > 1 for splits in hash_splits.values()):
        raise ValueError("Exact duplicate image bytes cross proposed split groups; resolve grouping first")
    for split in SPLITS:
        (out / "images" / split).mkdir(parents=True, exist_ok=True)
        (out / "labels" / split).mkdir(parents=True, exist_ok=True)
    for record in records:
        split, name = record["split"], record["filename"]
        record["image"] = f"images/{split}/{name}"
        record["label"] = f"labels/{split}/{Path(name).stem}.txt"
        record["materialization"] = materialize(Path(record["source_image"]), out / record["image"], image_mode)
        width, height = record["width"], record["height"]
        lines = []
        for box in record["instances"]:
            x1, y1, x2, y2 = box["xyxy"]
            values = ((x1 + x2) / (2 * width), (y1 + y2) / (2 * height),
                      (x2 - x1) / width, (y2 - y1) / height)
            lines.append("0 " + " ".join(f"{value:.10f}" for value in values))
        (out / record["label"]).write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    summary = {split: {"images": sum(r["split"] == split for r in records),
                       "instances": sum(r["count"] for r in records if r["split"] == split),
                       "groups": sorted(g for g, s in assignment.items() if s == split),
                       "dates": sorted({r["date"] for r in records if r["split"] == split})}
               for split in SPLITS}
    warnings = ["test is an INTERNAL holdout from labeled train, not the official test set.",
                "Do not tune thresholds, hyperparameters, epochs, or checkpoints on either test set.",
                "Group assignment balances only image counts; count distributions can differ substantially.",
                "Hardlinked images share source bytes: never edit prepared images in place."]
    if group_by == "sequence":
        warnings.append("Sequence-disjoint only: same-date/cross-sequence orchard or tree overlap cannot be excluded from filenames.")
    manifest = {"version": 1, "source_root": str(root), "output_root": str(out), "seed": seed,
                "group_by": group_by, "group_regex": NAME_RE.pattern,
                "requested_fractions": {"train": 1-val_fraction-test_fraction, "val": val_fraction, "test": test_fraction},
                "box_convention": "xyxy half-open pixel edges: xmax=max_pixel_x+1, ymax=max_pixel_y+1",
                "classes": {"0": "apple"}, "group_assignments": assignment, "summary": summary,
                "warnings": warnings, "records": records}
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    yaml = (f"# Internal grouped splits only; official test is not included.\npath: {json.dumps(out.as_posix())}\n"
            "train: images/train\nval: images/val\ntest: images/test\nnc: 1\nnames:\n  0: apple\n")
    (out / "data.yaml").write_text(yaml, encoding="utf-8")
    (out / "summary.json").write_text(json.dumps({"splits": summary, "warnings": warnings}, indent=2), encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--root", type=Path, default=Path("datasets/detection"), help="Extracted detection root containing train/images and train/masks")
    parser.add_argument("--out", type=Path, default=Path("prepared/detection"), help="Absent or empty output directory, separate from source")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--val-fraction", type=float, default=.15)
    parser.add_argument("--test-fraction", type=float, default=.15)
    parser.add_argument("--group-by", choices=("sequence", "date"), default="sequence")
    parser.add_argument("--image-mode", choices=("auto", "copy", "hardlink", "symlink"), default="auto",
                        help="auto: hardlink with copy fallback; images must be treated read-only")
    args = parser.parse_args()
    result = prepare(**vars(args))
    print(json.dumps({"output": str(args.out.resolve()), "summary": result["summary"], "warnings": result["warnings"]}, indent=2))


if __name__ == "__main__":
    main()
