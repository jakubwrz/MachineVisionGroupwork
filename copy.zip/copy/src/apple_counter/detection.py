"""YOLO orchard detector, validation-only confidence selection and count evaluation."""
from pathlib import Path
import argparse,csv,hashlib,json,time,warnings
from collections import Counter
import cv2
import numpy as np
from .common import count_metrics,save_json,seed_everything


def train(args):
    from ultralytics import YOLO
    seed_everything(args.seed)
    model=YOLO(args.model)
    model.train(data=str(Path(args.yaml).resolve()),epochs=args.epochs,imgsz=args.size,batch=args.batch,
                workers=args.workers,device=args.device,project=args.project,name=args.name,
                seed=args.seed,deterministic=True,patience=12,optimizer='AdamW',lr0=.001,
                lrf=.05,weight_decay=.0005,cos_lr=True,warmup_epochs=3,
                degrees=10,translate=.1,scale=.3,fliplr=.5,flipud=.2,
                mosaic=.5,close_mosaic=8,mixup=0,copy_paste=0,
                hsv_h=.015,hsv_s=.4,hsv_v=.3,amp=True,cache=False,plots=True,
                exist_ok=False,max_det=500)


def mask_boxes(path):
    from PIL import Image
    from .prepare_detection import instance_boxes
    with Image.open(path) as image:
        mask=np.asarray(image)  # Preserve indexed PNG instance IDs, including palette masks.
    return np.asarray([b['xyxy'] for b in instance_boxes(mask)],dtype=float).reshape(-1,4)


def load_records(data,prepared,split):
    root=Path(data)
    if split=='official_test':
        base=root/'test_data/detection';gt=json.loads((base/'ground_truth.json').read_text())
        grouped={im['id']:[] for im in gt['images']}
        for ann in gt['annotations']:
            x,y,w,h=ann['bbox']; grouped[ann['image_id']].append([x,y,x+w,y+h])
        return [(base/'images'/im.get('filename',im.get('file_name')),np.asarray(grouped[im['id']],dtype=float).reshape(-1,4))
                for im in sorted(gt['images'],key=lambda x:x['id'])]
    image_dir=Path(prepared)/'images'/split
    paths=sorted(image_dir.glob('*.png'))
    if not paths: raise FileNotFoundError(f'No images in {image_dir}')
    return [(p,mask_boxes(root/'detection/train/masks'/p.name)) for p in paths]


def checkpoint_sha256(weights):
    """Hash local checkpoint bytes so renamed/copied identical weights remain valid."""
    digest=hashlib.sha256()
    with Path(weights).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


def verify_selection_checkpoint(selection,weights):
    expected=selection.get('weights_sha256')
    if expected is None:
        warnings.warn('Legacy selection has no weights_sha256; checkpoint/threshold compatibility '
                      'cannot be verified. Regenerate selection with this checkpoint.',
                      RuntimeWarning,stacklevel=2)
        return
    if (not isinstance(expected,str) or len(expected)!=64 or
            any(c not in '0123456789abcdefABCDEF' for c in expected)):
        raise ValueError('Selection weights_sha256 must be a 64-character hexadecimal digest')
    actual=checkpoint_sha256(weights)
    if actual!=expected.lower():
        raise ValueError(f'Checkpoint SHA256 mismatch: selected threshold belongs to different weights '
                         f'(expected {expected}, got {actual}). Run validation selection for this checkpoint.')


def validate_apple_model(model):
    names=getattr(model,'names',None)
    if isinstance(names,dict):
        labels=list(names.values())
    elif isinstance(names,(list,tuple)):
        labels=list(names)
    else:
        labels=[]
    if len(labels)!=1 or not isinstance(labels[0],str) or labels[0].strip().lower()!='apple':
        raise ValueError(f'Expected a single-class apple model, got names={names!r}')


def validate_predictions(records,predictions):
    """Reject misalignment before zip-based metrics can silently report false results."""
    if len(records)!=len(predictions):
        raise ValueError(f'Record/prediction length mismatch: {len(records)} vs {len(predictions)}')
    for index,((path,gt),prediction) in enumerate(zip(records,predictions)):
        if not isinstance(prediction,dict) or prediction.get('image')!=Path(path).name:
            name=prediction.get('image') if isinstance(prediction,dict) else None
            raise ValueError(f'Prediction image mismatch at {index}: expected {Path(path).name!r}, got {name!r}')
        try:
            boxes=np.asarray(prediction['boxes'],dtype=float).reshape(-1,4)
            scores=np.asarray(prediction['scores'],dtype=float)
            ground_truth=np.asarray(gt,dtype=float).reshape(-1,4)
        except (KeyError,TypeError,ValueError) as exc:
            raise ValueError(f'Malformed predictions/ground truth for {Path(path).name}') from exc
        if scores.ndim!=1 or len(scores)!=len(boxes):
            raise ValueError(f'Box/score length or shape mismatch for {Path(path).name}')
        if not (np.isfinite(boxes).all() and np.isfinite(scores).all() and np.isfinite(ground_truth).all()):
            raise ValueError(f'Nonfinite predictions/ground truth for {Path(path).name}')


def run_predictions(model,records,size=960,confidence=.01,iou=.6,device='0'):
    validate_apple_model(model)
    predictions=[];start=time.perf_counter()
    for path,gt in records:
        result=model.predict(str(path),imgsz=size,conf=confidence,iou=iou,max_det=500,
                             device=device,verbose=False)[0]
        b=result.boxes
        predictions.append({'image':path.name,'boxes':b.xyxy.cpu().numpy().tolist(),
                            'scores':b.conf.cpu().numpy().tolist()})
    validate_predictions(records,predictions)
    return predictions,time.perf_counter()-start


def iou_matrix(a,b):
    a=np.asarray(a,dtype=float).reshape(-1,4);b=np.asarray(b,dtype=float).reshape(-1,4)
    lt=np.maximum(a[:,None,:2],b[None,:,:2]);rb=np.minimum(a[:,None,2:],b[None,:,2:])
    inter=np.maximum(rb-lt,0).prod(2)
    union=np.maximum(a[:,2:]-a[:,:2],0).prod(1)[:,None]+np.maximum(b[:,2:]-b[:,:2],0).prod(1)[None,:]-inter
    return inter/np.maximum(union,1e-12)


def localization_metrics(records,predictions,threshold):
    validate_predictions(records,predictions)
    tp=fp=fn=0
    for (_,gt),pr in zip(records,predictions):
        boxes=np.asarray(pr['boxes']).reshape(-1,4);scores=np.array(pr['scores']);keep=scores>=threshold
        boxes=boxes[keep];scores=scores[keep];overlap=iou_matrix(boxes,gt);used=set();hits=0
        for j in np.argsort(-scores):
            candidates=np.argsort(-overlap[j])
            for k in candidates:
                if overlap[j,k]<.5: break
                if int(k) not in used:used.add(int(k));hits+=1;break
        tp+=hits;fp+=len(boxes)-hits;fn+=len(gt)-hits
    precision=tp/max(tp+fp,1);recall=tp/max(tp+fn,1)
    return {'iou_threshold':.5,'matching':'confidence-ordered greedy, one-to-one',
            'tp':tp,'fp':fp,'fn':fn,'precision':precision,'recall':recall,
            'f1':2*precision*recall/max(precision+recall,1e-12)}


def select(args):
    from ultralytics import YOLO
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    weights_hash=checkpoint_sha256(args.weights)
    records=load_records(args.data,args.prepared,'val');model=YOLO(args.weights)
    validate_apple_model(model)
    predictions,seconds=run_predictions(model,records,args.size,.01,.6,args.device)
    validate_predictions(records,predictions)
    y=[len(gt) for p,gt in records]; trials=[]
    for conf in np.round(np.arange(.05,.76,.025),3):
        counts=[int((np.array(p['scores'])>=conf).sum()) for p in predictions]
        trials.append({'confidence':float(conf),**count_metrics(y,counts)})
    chosen=min(trials,key=lambda x:(x['mae'],x['rmse']))
    selection={'confidence':chosen['confidence'],'imgsz':args.size,'iou':.6,'max_det':500,
               'selected_on':'sequence-held-out validation only','weights':str(Path(args.weights).resolve()),
               'weights_sha256':weights_hash,
               'validation':chosen,'trials':trials,'inference_seconds':seconds}
    save_json(out/'selection.json',selection);save_json(out/'val_detections.json',predictions)
    write_results(out,'val',records,predictions,selection,seconds)
    print(json.dumps(selection,indent=2))


def write_results(out,split,records,predictions,selection,seconds):
    validate_predictions(records,predictions)
    conf=selection['confidence'];y=np.array([len(gt) for p,gt in records])
    pred=np.array([int((np.array(pr['scores'])>=conf).sum()) for pr in predictions])
    metrics=count_metrics(y,pred);metrics['localization']=localization_metrics(records,predictions,conf)
    metrics.update({'confidence':conf,'imgsz':selection['imgsz'],'seconds':seconds,'images_per_second':len(y)/max(seconds,1e-12)})
    groups={}
    for i,(path,gt) in enumerate(records):
        name=path.stem
        group=name.split('_image')[0] if '_image' in name else '_'.join(name.split('_')[:2])
        groups.setdefault(group,[]).append(i)
    metrics['per_sequence']={g:count_metrics(y[idx],pred[idx]) for g,idx in groups.items()}
    save_json(out/f'{split}_metrics.json',metrics)
    with (Path(out)/f'{split}_predictions.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['image','true_count','predicted_count','absolute_error'])
        w.writerows((p.name,int(a),int(b),int(abs(a-b))) for (p,gt),a,b in zip(records,y,pred))
    # Fixed evenly spaced examples, not cherry-picked by performance.
    vis=Path(out)/f'{split}_examples';vis.mkdir(exist_ok=True)
    for i in np.linspace(0,len(records)-1,min(6,len(records)),dtype=int):
        path,gt=records[i];im=cv2.imread(str(path))
        for box,score in zip(predictions[i]['boxes'],predictions[i]['scores']):
            if score<conf:continue
            x1,y1,x2,y2=map(int,box);cv2.rectangle(im,(x1,y1),(x2,y2),(0,255,255),2)
        cv2.rectangle(im,(0,0),(im.shape[1],55),(20,20,20),-1)
        cv2.putText(im,f'Pred: {pred[i]} | GT: {y[i]}',(12,36),cv2.FONT_HERSHEY_SIMPLEX,.9,(255,255,255),2)
        cv2.imwrite(str(vis/f'{path.stem}.jpg'),im)
    return metrics


def evaluate(args):
    from ultralytics import YOLO
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    selection=json.loads(Path(args.selection).read_text())
    verify_selection_checkpoint(selection,args.weights)
    model=YOLO(args.weights);validate_apple_model(model)
    records=load_records(args.data,args.prepared,args.split)
    predictions,seconds=run_predictions(model,records,selection['imgsz'],.01,selection['iou'],args.device)
    save_json(out/f'{args.split}_detections.json',predictions)
    metrics=write_results(out,args.split,records,predictions,selection,seconds)
    print(json.dumps(metrics,indent=2))


def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    t=sub.add_parser('train');t.add_argument('--yaml',default='datasets/yolo/data.yaml')
    t.add_argument('--model',default='yolo11n.pt');t.add_argument('--epochs',type=int,default=40)
    t.add_argument('--size',type=int,default=960);t.add_argument('--batch',type=int,default=8)
    t.add_argument('--workers',type=int,default=4);t.add_argument('--device',default='0');t.add_argument('--seed',type=int,default=42)
    t.add_argument('--project',default='runs');t.add_argument('--name',default='detector')
    for cmd in ['select','evaluate']:
        e=sub.add_parser(cmd);e.add_argument('--data',default='datasets');e.add_argument('--prepared',default='datasets/yolo')
        e.add_argument('--weights',default='runs/detector/weights/best.pt');e.add_argument('--out',default='results/detection')
        e.add_argument('--device',default='0')
        if cmd=='select':e.add_argument('--size',type=int,default=960)
        else:
            e.add_argument('--selection',default='results/detection/selection.json')
            e.add_argument('--split',choices=['test','official_test'],default='official_test')
    args=p.parse_args();{'train':train,'select':select,'evaluate':evaluate}[args.command](args)

if __name__=='__main__':main()
