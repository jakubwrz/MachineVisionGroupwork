"""Frozen full-image evaluation on reused controls, never used for tuning."""
from .runtime import configure_runtime
configure_runtime()
import argparse
from collections import Counter
import csv
from pathlib import Path
import re
import time
import torch
from PIL import Image
from .runtime import load_json, save_json, resources
from .paths import output_path, sha256
from .prepare_data import parent_records
from .metrics import summarize_parents, round_total
from .predict import load_frozen_model, predict_image, render_prediction


def official_records(labels, image_root):
    """Read COCO counts without using annotations in cropping or inference."""
    images = labels['images']; annotations = labels['annotations']
    ids = [r['id'] for r in images]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate COCO image ID')
    counts = Counter(); annotation_ids = set(); image_ids = set(ids)
    categories = labels.get('categories', [])
    if len(categories) > 1:
        raise ValueError('Multi-category COCO needs explicit apple category filtering')
    category_ids = {c['id'] for c in categories}
    for row in annotations:
        if category_ids and 'category_id' in row and row['category_id'] not in category_ids:
            raise ValueError('Annotation references undeclared category')
        if row['image_id'] not in image_ids:
            raise ValueError('Annotation references unknown image')
        if 'id' in row:
            if row['id'] in annotation_ids:
                raise ValueError('Duplicate annotation ID')
            annotation_ids.add(row['id'])
        if row.get('iscrowd', 0):
            raise ValueError('Crowd annotations need an explicit count policy')
        counts[row['image_id']] += 1
    root = Path(image_root).resolve(); result = []; filenames = set()
    for row in sorted(images, key=lambda r: r.get('filename', r.get('file_name', ''))):
        name = row.get('filename', row.get('file_name'))
        if not isinstance(name, str) or not name or name in filenames:
            raise ValueError('Invalid/duplicate image filename')
        filenames.add(name)
        path = (root / name).resolve()
        if not path.is_relative_to(root):
            raise ValueError('Official image filename escapes image root')
        stem = Path(name).stem
        match = re.match(r'^(\d{8}_\d{6})_', stem) or re.match(r'^(dataset\d+_(?:front|back))_\d+$', stem)
        result.append({'filename': name, 'source_image': str(path),
                       'group': match[1] if match else 'official_unmapped',
                       'count': counts[row['id']]})
    return result


def legacy_comparison(rows, csv_path):
    with open(csv_path, newline='', encoding='utf-8-sig') as stream:
        old = list(csv.DictReader(stream))
    mapping = {r['image']: r for r in old}
    if len(mapping) != len(old) or set(mapping) != {r['filename'] for r in rows}:
        raise ValueError('Legacy prediction membership mismatch')
    baseline = []
    for row in rows:
        old_row = mapping[row['filename']]
        if float(old_row['true_count']) != row['target']:
            raise ValueError('Legacy/new count target mismatch')
        baseline.append({**row, 'prediction': float(old_row['predicted_count'])})
    old_metrics = summarize_parents(baseline)
    new_metrics = summarize_parents(rows)
    return {'legacy': old_metrics, 'new_minus_legacy_mae': new_metrics['continuous']['mae'] - old_metrics['continuous']['mae'],
            'caution': 'Same fixed reused controls. Negative delta is lower MAE, not proof of external generalization.'}


def evaluate_split(selection_path, split, device='cuda', resume=False):
    torch.set_num_threads(4)
    model, config, selection = load_frozen_model(selection_path, device)
    resource = resources()['resources']
    # No test labels are read until load_frozen_model verified the selected hash.
    if split == 'official':
        label_path = resource['official_detection_labels']
        parents = official_records(load_json(label_path), resource['official_detection_images'])
        baseline_csv = resource['baseline_official_predictions']
    else:
        label_path = resource['parent_split_manifest']
        if sha256(label_path) != config['manifest_sha256']:
            raise ValueError('Internal/validation parent manifest changed since protocol freeze')
        parents = parent_records(load_json(label_path), split)
        baseline_csv = resource['baseline_internal_predictions'] if split == 'test' else str(Path(resource['baseline_internal_predictions']).with_name('val_predictions.csv'))
    directory = output_path(f'results/core_v1/{split}')
    identity = {'checkpoint_sha256': selection['checkpoint_sha256'],
                'protocol_sha256': selection['protocol_sha256'],
                'label_file_sha256': sha256(label_path), 'split': split,
                'device': device, 'torch_version': torch.__version__,
                'baseline_csv_sha256': sha256(baseline_csv),
                'prediction_source_sha256': sha256(Path(__file__).with_name('predict.py')),
                'evaluation_source_sha256': sha256(__file__)}
    rows = []; times = []; previous_seconds = 0.
    if directory.exists():
        if not resume:
            raise FileExistsError('Evaluation directory exists; use --resume ONLY for interrupted frozen evaluation')
        state = load_json(directory / 'state.json')
        if state['status'] == 'completed' or state['identity'] != identity:
            raise ValueError('Cannot resume completed evaluation or changed checkpoint/data/implementation')
        partial = load_json(directory / 'partial.json')
        rows, times, previous_seconds = partial['rows'], partial['times'], partial['elapsed_seconds']
        if len(rows) != len(times) or [r['filename'] for r in rows] != [p['filename'] for p in parents[:len(rows)]]:
            raise ValueError('Interrupted result prefix mismatch')
    else:
        directory.mkdir(parents=True)
        save_json({'status': 'running', 'identity': identity}, directory / 'state.json')
        save_json({'rows': [], 'times': [], 'elapsed_seconds': 0.}, directory / 'partial.json')
    visual_indices = {0, len(parents)//2, len(parents)-1}
    start = time.perf_counter(); start_index = len(rows)
    for index, parent in enumerate(parents):
        if index < start_index:
            continue
        with Image.open(parent['source_image']) as image:
            prediction = predict_image(model, image, config['core_size'], config['halo'], device, config['batch_size'])
            if index in visual_indices:
                render_prediction(image, prediction, directory / f'example_{index:03d}.png')
        rows.append({'filename': parent['filename'], 'group': parent['group'], 'target': parent['count'],
                     'prediction': prediction['prediction'], 'rounded_after_sum': prediction['rounded_after_sum'],
                     'tile_predictions': prediction['tile_predictions']})
        times.append(prediction['seconds'])
        if (index + 1) % 25 == 0 or index == len(parents)-1:
            # Commit partial results atomically; interrupted evaluation can resume
            # the identical frozen checkpoint without reselecting or tuning it.
            staged = save_json({'rows': rows, 'times': times,
                                'elapsed_seconds': previous_seconds + time.perf_counter()-start},
                               directory / 'partial.pending.json')
            staged.replace(output_path(directory / 'partial.json'))
            print(f'{split}: {index+1}/{len(parents)}', flush=True)
    report = summarize_parents(rows)
    report.update({'split': split, 'checkpoint_sha256': selection['checkpoint_sha256'],
                   'protocol_sha256': selection['protocol_sha256'], 'label_file_sha256': sha256(label_path),
                   'evaluation_role': 'validation verification' if split == 'val' else 'reused control, NOT a new blind test',
                   'seconds_total_including_io_visualization': previous_seconds + time.perf_counter() - start,
                   'evidence_identity': identity,
                   'seconds_crop_tensor_model_sum': sum(times),
                   'images_per_second_crop_tensor_model_sum': len(parents)/sum(times),
                   'device': device, 'batch_size': config['batch_size'],
                   'speed_caveat': 'Shared GPU with other applications, includes per-image crop/tensor transfer, excludes model load; not a controlled hardware benchmark.',
                   'comparison': legacy_comparison(rows, baseline_csv)})
    save_json(rows, directory / 'predictions.json')
    save_json(report, directory / 'metrics.json')
    csv_path = output_path(directory / 'predictions.csv')
    with csv_path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=['image', 'group', 'true_count', 'predicted_count', 'rounded_count', 'absolute_error'])
        writer.writeheader()
        for row in rows:
            writer.writerow({'image': row['filename'], 'group': row['group'], 'true_count': row['target'],
                             'predicted_count': row['prediction'], 'rounded_count': round_total(row['prediction']),
                             'absolute_error': abs(row['prediction']-row['target'])})
    save_json({'status': 'completed', 'identity': identity, 'images': len(rows)}, directory / 'state.json')
    print(report['continuous'])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selection', default='runs/core_v1/selection.json')
    parser.add_argument('--split', choices=['val', 'test', 'official'], required=True)
    parser.add_argument('--device', choices=['cuda', 'cpu'], default='cuda')
    parser.add_argument('--resume', action='store_true', help='Resume interrupted evaluation of exactly the same frozen model/data/code')
    args = parser.parse_args()
    evaluate_split(args.selection, args.split, args.device, args.resume)


if __name__ == '__main__':
    main()
