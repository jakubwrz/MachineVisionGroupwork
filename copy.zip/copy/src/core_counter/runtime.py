"""Isolated runtime and small serialization helpers (no legacy imports)."""
import json
import os
from .paths import PROJECT_ROOT, output_path


def configure_runtime():
    for key, relative in {'TORCH_HOME': 'cache/torch', 'MPLCONFIGDIR': 'cache/matplotlib',
                          'YOLO_CONFIG_DIR': 'cache/ultralytics', 'TEMP': 'tmp', 'TMP': 'tmp',
                          'XDG_CACHE_HOME': 'cache', 'HF_HOME': 'cache/huggingface',
                          'TORCHINDUCTOR_CACHE_DIR': 'cache/inductor'}.items():
        path = output_path(relative)
        path.mkdir(parents=True, exist_ok=True)
        os.environ[key] = str(path)
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')


def load_json(path):
    with open(path, encoding='utf-8') as stream:
        return json.load(stream)


def save_json(value, path):
    destination = output_path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    return destination


def resources():
    return load_json(PROJECT_ROOT / 'config/resources.json')
