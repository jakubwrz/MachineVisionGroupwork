"""One protocol-locked, bounded ImageNet-initialized core-counting experiment."""
from .runtime import configure_runtime
configure_runtime()
import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import random
import time
import numpy as np
import torch
from torch.utils.data import DataLoader
from .paths import PROJECT_ROOT, output_path, sha256
from .runtime import load_json, save_json, resources
from .dataset import CoreDataset, ParentBalancedSampler
from .metrics import aggregate_tiles, count_metrics, summarize_parents
from .model import CoreCounter, freeze_batch_norm


def seed_everything(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.set_num_threads(4)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True, warn_only=False)


@torch.inference_mode()
def validate(model, loader, device):
    model.eval(); predictions = []; tile_truth = []; tile_pred = []
    start = time.perf_counter()
    for batch in loader:
        pred = model(batch['rgb'].to(device), batch['core_mask'].to(device)).cpu().tolist()
        for parent, tile, value in zip(batch['parent_index'].tolist(), batch['tile_index'].tolist(), pred):
            predictions.append((parent, tile, value))
        tile_truth.extend(batch['target'].tolist()); tile_pred.extend(pred)
    rows = aggregate_tiles(loader.dataset.parents, predictions)
    report = summarize_parents(rows)
    report['tiles'] = count_metrics(tile_truth, tile_pred)
    occupied = [(t, p) for t, p in zip(tile_truth, tile_pred) if t > 0]
    report['nonempty_tiles'] = count_metrics(*zip(*occupied)) if occupied else {'n': 0}
    report['seconds_including_io'] = time.perf_counter() - start
    return report, rows


def simple_baselines(train_data, val_data):
    mean = float(np.mean([p['count'] for p in train_data['parents']]))
    result = {}
    for name, value in [('zero', 0.), ('train_parent_mean', mean)]:
        rows = [{'filename': p['filename'], 'group': p['group'], 'target': p['count'],
                 'prediction': value} for p in val_data['parents']]
        result[name] = summarize_parents(rows)
    result['train_only_constant'] = mean
    return result


def validate_protocol(config):
    for key in ('max_epochs', 'batch_size', 'tiles_per_parent', 'patience', 'core_size', 'planned_runs'):
        if isinstance(config[key], bool) or not isinstance(config[key], int) or config[key] < 1:
            raise ValueError(f'{key} must be a positive integer')
    for key in ('backbone_lr', 'head_lr', 'gradient_clip', 'upgrade_overall_ratio', 'upgrade_sequence_ratio'):
        if not math.isfinite(config[key]) or config[key] <= 0:
            raise ValueError(f'{key} must be finite and positive')
    for key in ('weight_decay', 'min_delta'):
        if not math.isfinite(config[key]) or config[key] < 0:
            raise ValueError(f'{key} must be finite and nonnegative')
    if isinstance(config['halo'], bool) or not isinstance(config['halo'], int) or config['halo'] < 0:
        raise ValueError('halo must be nonnegative integer')
    if config['max_epochs'] > 12 or config['planned_runs'] != 1:
        raise ValueError('v1 is explicitly capped at one run, <=12 epochs')
    if config['selection_metric'] != 'validation_full_parent_continuous_mae':
        raise ValueError('Unsupported selection metric')
    for name, digest in config.get('training_source_sha256', {}).items():
        if sha256(output_path(name)) != digest:
            raise ValueError(f'Training implementation changed after protocol freeze: {name}')
    resource = resources()
    if config['manifest_sha256'] != sha256(resource['resources']['parent_split_manifest']):
        raise ValueError('Fixed source manifest has changed')
    if config['training_audit_sha256'] != sha256(output_path('data/derived/training_audit.json')):
        raise ValueError('Training audit changed after protocol selection')
    init_path = output_path(config['imagenet_path'])
    if sha256(init_path) != config['imagenet_sha256']:
        raise ValueError('ImageNet initialization hash mismatch')
    from .prepare_data import validate_manifest
    manifest = load_json(resource['resources']['parent_split_manifest'])
    validate_manifest(manifest)
    for split in ('train', 'val'):
        data_path = output_path(config[f'{split}_data'])
        if sha256(data_path) != config[f'{split}_data_sha256']:
            raise ValueError(f'{split} derived data changed')
        data = load_json(data_path)
        if data['split'] != split or any(p['split'] != split for p in data['parents']):
            raise ValueError('Data split contamination')
        if data['manifest_sha256'] != config['manifest_sha256']:
            raise ValueError('Derived manifest mismatch')
        if (data['core_size'], data['halo']) != (config['core_size'], config['halo']):
            raise ValueError('Data geometry disagrees with protocol')
        fixed = {r['filename']: r for r in manifest['records'] if r['split'] == split}
        if len(data['parents']) != len(fixed) or {p['filename'] for p in data['parents']} != set(fixed):
            raise ValueError('Derived parent membership differs from fixed manifest')
        for parent in data['parents']:
            source = fixed[parent['filename']]
            for key in ('group', 'split', 'width', 'height', 'count'):
                if parent[key] != source[key]:
                    raise ValueError(f'Derived parent {key} differs from fixed manifest')
            if Path(parent['source_image']).resolve() != Path(source['source_image']).resolve():
                raise ValueError('Derived image path differs from fixed manifest')
        CoreDataset(data)  # Validate integer, nonnegative and conserved targets before training.


def run(config_path, device_name='cuda'):
    config_path = output_path(config_path)
    config = load_json(config_path); validate_protocol(config)
    run_dir = output_path(config['run_dir'])
    if run_dir.exists():
        raise FileExistsError('Refusing to overwrite/restart a v1 experiment run')
    run_dir.mkdir(parents=True)
    save_json(config, run_dir / 'protocol.json')
    seed_everything(config['seed'])
    device = torch.device(device_name)
    if device.type == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; do not silently change experiment runtime')
    train_data = load_json(output_path(config['train_data']))
    val_data = load_json(output_path(config['val_data']))
    training = CoreDataset(train_data, augment=True)
    validation = CoreDataset(val_data)
    sampler = ParentBalancedSampler(training, config['tiles_per_parent'], config['seed'])
    train_loader = DataLoader(training, batch_size=config['batch_size'], sampler=sampler, num_workers=0)
    val_loader = DataLoader(validation, batch_size=config['batch_size'], shuffle=False, num_workers=0)
    model = CoreCounter(output_path(config['imagenet_path'])).to(device)
    optimizer = torch.optim.AdamW([
        {'params': model.backbone.parameters(), 'lr': config['backbone_lr']},
        {'params': model.density_head.parameters(), 'lr': config['head_lr']}],
        weight_decay=config['weight_decay'])
    save_json(simple_baselines(train_data, val_data), run_dir / 'simple_baselines.json')
    best, bad_epochs, history = float('inf'), 0, []
    best_epoch = None
    protocol_hash = sha256(config_path)
    started = datetime.now(timezone.utc).isoformat()
    info = {'started_utc': started, 'protocol_sha256': protocol_hash, 'device': str(device),
            'torch': torch.__version__, 'numpy': np.__version__, 'planned_epochs': config['max_epochs'],
            'deterministic_algorithms': True, 'mixed_precision': False,
            'workers': 0, 'status': 'running'}
    save_json(info, run_dir / 'status.json')
    try:
        for epoch in range(1, config['max_epochs'] + 1):
            if sha256(config_path) != protocol_hash:
                raise RuntimeError('Protocol changed during training')
            sampler.set_epoch(epoch)
            freeze_batch_norm(model.train())
            losses = []; epoch_start = time.perf_counter()
            for step, batch in enumerate(train_loader):
                rgb = batch['rgb'].to(device); core = batch['core_mask'].to(device)
                target = batch['target'].to(device, dtype=torch.float32)
                optimizer.zero_grad(set_to_none=True)
                prediction = model(rgb, core)
                # Poisson count likelihood up to target-only factorial, uncapped counts.
                loss = torch.nn.functional.poisson_nll_loss(prediction, target, log_input=False, full=False, eps=1e-8)
                if not torch.isfinite(loss):
                    raise FloatingPointError('Nonfinite loss')
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), config['gradient_clip'], error_if_nonfinite=True)
                optimizer.step(); losses.append(float(loss.detach()))
                if step % 100 == 0:
                    print(f'epoch={epoch} step={step}/{len(train_loader)} loss={losses[-1]:.5f}', flush=True)
            report, rows = validate(model, val_loader, device)
            score = report['continuous']['mae']
            record = {'epoch': epoch, 'train_poisson_nll': float(np.mean(losses)),
                      'seconds': time.perf_counter() - epoch_start, 'validation': report}
            history.append(record); save_json(history, run_dir / 'history.json')
            print(json.dumps({'epoch': epoch, 'val_mae': score, 'sequence_mae': report['equal_sequence_mae'],
                              'seconds': record['seconds']}), flush=True)
            if score < best - config['min_delta']:
                best, bad_epochs, best_epoch = score, 0, epoch
                torch.save({'model': model.state_dict(), 'epoch': epoch, 'config': config,
                            'protocol_sha256': protocol_hash, 'validation_mae': best}, output_path(run_dir / 'best.pt'))
                save_json(rows, run_dir / 'best_val_predictions.json')
                save_json(report, run_dir / 'best_val_metrics.json')
            else:
                bad_epochs += 1
            if bad_epochs >= config['patience']:
                break
        baseline = config['legacy_validation_reference']
        best_report = load_json(run_dir / 'best_val_metrics.json')
        passes = (best_report['continuous']['mae'] <= baseline['mae'] * config['upgrade_overall_ratio']
                  and all(best_report['groups'][g]['mae'] <= v * config['upgrade_sequence_ratio']
                          for g, v in baseline['group_mae'].items()))
        selection = {'status': 'frozen', 'frozen_utc': datetime.now(timezone.utc).isoformat(),
                     'protocol_sha256': protocol_hash, 'checkpoint': str(run_dir / 'best.pt'),
                     'checkpoint_sha256': sha256(run_dir / 'best.pt'), 'best_epoch': best_epoch,
                     'completed_epochs': len(history), 'validation_mae': best,
                     'prediction_rule': 'sum continuous nonnegative cores; optional floor(total+0.5) only after sum',
                     'upgrade_validation_gate_passed': passes, 'default_remains_legacy': not passes,
                     'test_policy': 'reused controls, not unseen blind tests; no tuning after this freeze'}
        save_json(selection, run_dir / 'selection.json')
        info.update(status='completed', completed_epochs=len(history), best_epoch=best_epoch)
        save_json(info, run_dir / 'status.json')
        return selection
    except BaseException as exc:
        info.update(status='failed_or_interrupted', error=repr(exc), completed_epochs=len(history))
        save_json(info, run_dir / 'status.json')
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default='config/experiment_v1.json')
    parser.add_argument('--device', choices=['cuda', 'cpu'], default='cuda')
    args = parser.parse_args()
    print(json.dumps(run(args.config, args.device), indent=2))


if __name__ == '__main__':
    main()
