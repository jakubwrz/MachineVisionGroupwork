"""Label-free full-image inference: geometry from RGB size, sum each core once."""
from .runtime import configure_runtime
configure_runtime()
import argparse
import math
from pathlib import Path
import time
import torch
from PIL import Image, ImageDraw
from .dataset import tensor_tile
from .geometry import make_grid, extract_tile
from .model import CoreCounter
from .metrics import round_total
from .paths import output_path, sha256
from .runtime import load_json, save_json


def load_frozen_model(selection_path, device='cpu'):
    selection_path = output_path(selection_path)
    selection = load_json(selection_path)
    if selection.get('status') != 'frozen':
        raise ValueError('Selection must be frozen before inference/evaluation')
    checkpoint_path = output_path(selection['checkpoint'])
    if sha256(checkpoint_path) != selection['checkpoint_sha256']:
        raise ValueError('Frozen checkpoint changed')
    if sha256(checkpoint_path.with_name('protocol.json')) != selection['protocol_sha256']:
        raise ValueError('Frozen protocol snapshot changed')
    checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
    if checkpoint['protocol_sha256'] != selection['protocol_sha256']:
        raise ValueError('Checkpoint/selection protocol mismatch')
    for name in ('geometry', 'dataset', 'model', 'metrics'):
        relative = f'src/core_counter/{name}.py'
        expected = checkpoint['config'].get('training_source_sha256', {}).get(relative)
        if expected and sha256(output_path(relative)) != expected:
            raise ValueError(f'Inference dependency changed since training freeze: {name}')
    model = CoreCounter()
    model.load_state_dict(checkpoint['model'], strict=True)
    return model.to(device).eval(), checkpoint['config'], selection


@torch.inference_mode()
def predict_image(model, image, core_size, halo, device='cpu', batch_size=8):
    if batch_size <= 0:
        raise ValueError('Positive batch size required')
    image = image.convert('RGB')
    tiles = make_grid(*image.size, core_size, halo)
    predictions = []
    start = time.perf_counter()
    for offset in range(0, len(tiles), batch_size):
        tensors = [tensor_tile(*extract_tile(image, tile)) for tile in tiles[offset:offset + batch_size]]
        rgb = torch.stack([x[0] for x in tensors]).to(device)
        core = torch.stack([x[1] for x in tensors]).to(device)
        predictions.extend(model(rgb, core).detach().cpu().tolist())
    if len(predictions) != len(tiles) or any(not math.isfinite(v) or v < 0 for v in predictions):
        raise ValueError('Missing/invalid core prediction')
    total = math.fsum(predictions)
    return {'width': image.width, 'height': image.height, 'prediction': total,
            'rounded_after_sum': round_total(total), 'core_size': core_size, 'halo': halo,
            'tile_predictions': predictions, 'tiles': tiles,
            'seconds': time.perf_counter() - start,
            'rule': 'sum continuous nonnegative predictions; round only full-image total'}


def render_prediction(image, result, destination):
    base = image.convert('RGB')
    overlay = Image.new('RGBA', base.size, (0, 0, 0, 0)); draw = ImageDraw.Draw(overlay)
    maximum = max(max(result['tile_predictions']), 1e-6)
    for tile, value in zip(result['tiles'], result['tile_predictions']):
        x0, y0, x1, y1 = tile['core']
        draw.rectangle((x0, y0, x1-1, y1-1), fill=(255, 45, 10, int(140 * value / maximum)),
                       outline=(0, 255, 255, 255), width=2)
        # A final valid core may be only one pixel wide/high. Never create
        # inverted label rectangles; its count remains available in JSON.
        if x1-x0 >= 20 and y1-y0 >= 20:
            draw.rectangle((x0+2, y0+2, min(x1-1, x0+91), min(y1-1, y0+19)), fill=(0, 0, 0, 220))
            draw.text((x0+4, y0+4), f"{tile['index']}: {value:.2f}", fill='white')
    annotated = Image.alpha_composite(base.convert('RGBA'), overlay).convert('RGB')
    result_image = Image.new('RGB', (base.width, base.height+35), 'black')
    result_image.paste(annotated, (0, 35)); draw = ImageDraw.Draw(result_image)
    draw.text((8, 10), f"Core SUM = {result['prediction']:.2f} | rounded total = {result['rounded_after_sum']}", fill='white')
    path = output_path(destination); path.parent.mkdir(parents=True, exist_ok=True)
    result_image.save(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', required=True)
    parser.add_argument('--selection', default='runs/core_v1/selection.json')
    parser.add_argument('--output', default='results/predict/prediction.json')
    parser.add_argument('--device', choices=['cpu', 'cuda'], default='cpu')
    args = parser.parse_args()
    torch.set_num_threads(4)
    model, config, selection = load_frozen_model(args.selection, args.device)
    with Image.open(args.image) as image:
        result = predict_image(model, image, config['core_size'], config['halo'], args.device, config['batch_size'])
        render_prediction(image, result, output_path(args.output).with_suffix('.png'))
    result['checkpoint_sha256'] = selection['checkpoint_sha256']
    result['source_image'] = str(Path(args.image).resolve())
    save_json(result, args.output)
    print(f"Core sum={result['prediction']:.3f}, rounded={result['rounded_after_sum']}")


if __name__ == '__main__':
    main()
