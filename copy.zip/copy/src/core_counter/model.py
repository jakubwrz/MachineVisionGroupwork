"""Offline ImageNet RGB backbone with explicit valid-core density integration.

Inputs are ImageNet-normalized RGB and a binary (or fractional [0, 1]) mask
marking only valid core pixels, never halo or image-padding pixels. The RGB
backbone ends at ResNet18 layer3 (256 channels, nominal stride 16). A light
256 -> 64 -> 1 head predicts softplus density per 16 x 16 input-pixel area.
There is no 0--6 classification or output cap, and no division by core area.

Mask integration pads only the mask on the bottom/right to the feature grid's
nominal stride, then area-resamples it. Thus each weight is the fraction of a
16 x 16 cell covered by valid core pixels; even odd-sized edge crops conserve
mask area exactly. The coarse density grid is an approximation near boundaries,
not instance-level localization. RGB context may influence core predictions,
but density outside the supplied core never contributes directly to the sum.

No weights are downloaded. ``imagenet_path=None`` is random initialization for
tests; formal training must require an audited local ImageNet state_dict copy.
Normalize RGB in the data pipeline using mean=(.485, .456, .406) and
std=(.229, .224, .225). The final head bias starts at -4 and weights at small
nonzero values, giving gentle positive predictions while allowing backbone
gradients from the first step. For small batches call ``freeze_batch_norm``
AFTER every ``model.train()``; affine BN parameters remain trainable.
"""
from collections import OrderedDict
from pathlib import Path

import torch
from torch import Tensor, nn
from torch.nn import functional as F
from torchvision.models import resnet18


class CoreCounter(nn.Module):
    """Predict one nonnegative, uncapped count per RGB/context crop.

    ``imagenet_path`` must contain the raw torchvision ResNet18 state_dict,
    including its original 1000-class head. It is loaded strictly on CPU with
    ``weights_only=True`` before unused layer4/average-pool/classifier removal.
    A CoreCounter training checkpoint instead uses ``load_state_dict`` on this
    class; it must not be passed as ImageNet initialization.
    """

    feature_stride = 16

    def __init__(self, imagenet_path: str | Path | None = None):
        super().__init__()
        network = resnet18(weights=None)
        if imagenet_path is not None:
            path = Path(imagenet_path)
            if not path.is_file():
                raise FileNotFoundError(f"Local ImageNet state_dict not found: {path}")
            state = torch.load(path, map_location="cpu", weights_only=True)
            network.load_state_dict(state, strict=True)
        self.backbone = nn.Sequential(OrderedDict(
            (name, getattr(network, name))
            for name in ("conv1", "bn1", "relu", "maxpool", "layer1", "layer2", "layer3")
        ))
        self.density_head = nn.Sequential(
            nn.Conv2d(256, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 1, kernel_size=1),
        )
        nn.init.normal_(self.density_head[-1].weight, mean=0.0, std=0.001)
        nn.init.constant_(self.density_head[-1].bias, -4.0)

    def forward(self, rgb: Tensor, core_mask: Tensor) -> Tensor:
        """Map RGB ``[B,3,H,W]`` and valid core ``[B,1,H,W]`` to ``[B]``.

        Invalid shapes, nonfinite inputs, or mask values outside [0, 1] raise
        an error instead of silently changing the core geometry. All-zero
        masks produce exact zero and zero parameter gradients for that item.
        """
        if rgb.ndim != 4 or rgb.shape[1] != 3:
            raise ValueError("rgb must have shape [B, 3, H, W]")
        if min(rgb.shape[0], rgb.shape[2], rgb.shape[3]) <= 0:
            raise ValueError("rgb batch and spatial dimensions must be positive")
        if core_mask.shape != (rgb.shape[0], 1, rgb.shape[2], rgb.shape[3]):
            raise ValueError("core_mask must have shape [B, 1, H, W] matching rgb")
        if not rgb.is_floating_point():
            raise TypeError("rgb must be floating point and ImageNet-normalized")
        if core_mask.is_complex():
            raise TypeError("core_mask must be real-valued")
        if rgb.device != core_mask.device:
            raise ValueError("rgb and core_mask must be on the same device")
        if not torch.isfinite(rgb).all() or not torch.isfinite(core_mask).all():
            raise ValueError("rgb and core_mask must be finite")
        if (core_mask < 0).any() or (core_mask > 1).any():
            raise ValueError("core_mask values must lie in [0, 1]")

        logits = self.density_head(self.backbone(rgb))
        # Keep the density and sum in float32 under mixed precision.
        if logits.dtype in (torch.float16, torch.bfloat16):
            logits = logits.float()
        density = F.softplus(logits)
        height, width = density.shape[-2:]
        stride = self.feature_stride
        mask = core_mask.to(dtype=density.dtype)
        mask = F.pad(mask, (0, width * stride - rgb.shape[-1],
                            0, height * stride - rgb.shape[-2]))
        coverage = F.interpolate(mask, size=(height, width), mode="area")
        return (density * coverage).sum(dim=(1, 2, 3))


def freeze_batch_norm(model: nn.Module) -> nn.Module:
    """Freeze BN running statistics, retaining trainable affine parameters.

    Call after each ``model.train()`` (which recursively re-enables BN training).
    This helper does not freeze convolution parameters, disable autograd, or
    switch the density head to evaluation mode. Returns the model for chaining.
    """
    for module in model.modules():
        if isinstance(module, nn.modules.batchnorm._BatchNorm):
            module.eval()
    return model
