"""Prepare core labels from fixed parent splits; never resplit or edit sources."""
import argparse
from collections import Counter
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
from .paths import output_path, sha256
from .runtime import configure_runtime, load_json, save_json, resources
from .geometry import make_grid, instance_centroids, assign_targets, read_instance_mask


def validate_manifest(manifest):
    seen_names, seen_paths, seen_hashes, groups = set(), set(), {}, {}
    totals = Counter()
    for row in manifest['records']:
        split = row['split']
        if split not in {'train', 'val', 'test'}:
            raise ValueError(f'Unknown split: {split}')
        path = str(Path(row['source_image']).resolve())
        if row['filename'] in seen_names or path in seen_paths:
            raise ValueError('Duplicate parent filename/path')
        seen_names.add(row['filename']); seen_paths.add(path)
        group = row['group']
        if group in groups and groups[group] != split:
            raise ValueError('Sequence leakage across splits')
        groups[group] = split
        if manifest.get('group_assignments', {}).get(group, split) != split:
            raise ValueError('Group assignment mismatch')
        digest = row.get('image_sha256')
        if digest and digest in seen_hashes and seen_hashes[digest] != split:
            raise ValueError('Exact parent image hash leakage across splits')
        if digest:
            seen_hashes[digest] = split
        if min(row['width'], row['height']) <= 0:
            raise ValueError('Invalid parent dimensions')
        totals[split] += 1
    for split, summary in manifest.get('summary', {}).items():
        if summary['images'] != totals[split]:
            raise ValueError('Manifest split total mismatch')
    return {'parents': dict(totals), 'groups': groups,
            'checks': ['unique parent filename/path', 'sequence disjoint', 'stored image hashes cross-split disjoint'],
            'caveat': 'Stored hashes are checked for overlap; no claim to rule out near duplicates or cross-sequence same-tree overlap.'}


def parent_records(manifest, split):
    validate_manifest(manifest)
    return sorted((r for r in manifest['records'] if r['split'] == split), key=lambda r: r['filename'])


def describe_counts(values):
    a = np.asarray(values, dtype=np.float64)
    return {'tiles': len(values), 'sum': int(a.sum()), 'mean': float(a.mean()),
            'max': int(a.max()), 'empty_fraction': float((a == 0).mean()),
            'over_six': int((a > 6).sum()),
            'quantiles': {str(q): float(np.quantile(a, q)) for q in [0.5, 0.9, 0.95, 0.99]},
            'histogram': dict(sorted(Counter(map(int, values)).items()))}


def annotated_parent(row, mask, tiles, targets, path):
    with Image.open(row['source_image']) as source:
        image = source.convert('RGB')
    draw = ImageDraw.Draw(image)
    points = instance_centroids(mask)
    for tile, target in zip(tiles, targets):
        x0, y0, x1, y1 = tile['core']
        draw.rectangle((x0, y0, x1 - 1, y1 - 1), outline='#00ffff', width=2)
        draw.rectangle((x0 + 3, y0 + 3, x0 + 72, y0 + 21), fill='black')
        draw.text((x0 + 5, y0 + 5), f"{tile['index']}: {target}", fill='white')
    for x, y in points.values():
        draw.ellipse((x - 2, y - 2, x + 2, y + 2), fill='#ffff00')
    # Highlight one input context, showing overlap without changing ownership.
    tile = tiles[min(5, len(tiles) - 1)]
    draw.rectangle(tuple(tile['crop']), outline='#ff33aa', width=3)
    destination = output_path(path); destination.parent.mkdir(parents=True, exist_ok=True)
    image.save(destination)


def audit_training(core_sizes=(128, 192), halo=32):
    config = resources(); manifest_path = config['resources']['parent_split_manifest']
    manifest = load_json(manifest_path); split_audit = validate_manifest(manifest)
    rows = parent_records(manifest, 'train')
    counts = {size: [] for size in core_sizes}; dimensions = Counter()
    per_parent = []
    for index, row in enumerate(rows):
        mask = read_instance_mask(row['source_mask'])
        if mask.shape != (row['height'], row['width']):
            raise ValueError('Mask dimensions mismatch')
        with Image.open(row['source_image']) as image:
            if image.size != (row['width'], row['height']):
                raise ValueError('Image dimensions mismatch')
        actual = len(instance_centroids(mask))
        if actual != row['count']:
            raise ValueError(f"Unique instance count differs from manifest: {row['filename']}")
        dimensions[str((row['width'], row['height']))] += 1
        per_parent.append(actual)
        for size in core_sizes:
            tiles = make_grid(row['width'], row['height'], size, halo)
            targets = assign_targets(mask, tiles)
            if sum(targets) != actual:
                raise AssertionError('Label conservation failed')
            counts[size].extend(targets)
            if index in (0, len(rows)//2, len(rows)-1):
                annotated_parent(row, mask, tiles, targets, f'results/audit/train_{index:03d}_core{size}.png')
        if (index + 1) % 50 == 0:
            print(f'Training audit {index+1}/{len(rows)}', flush=True)
    report = {'manifest_sha256': sha256(manifest_path), 'label_source': 'training parents ONLY',
              'ownership': 'centroid of all pixel centers (x+0.5,y+0.5) per nonzero instance ID',
              'split_audit': split_audit, 'dimensions': dict(dimensions),
              'parents': len(rows), 'instances': sum(per_parent), 'parent_max': max(per_parent),
              'halo': halo, 'candidates': {str(size): describe_counts(v) for size, v in counts.items()},
              'conservation': 'PASS for every training parent and candidate',
              'visual_samples': 'sorted training parent indices 0,233,465; cyan=core, yellow=centroid, pink=one context crop'}
    save_json(report, 'data/derived/training_audit.json')
    return report


def prepare_split(split, core_size, halo, destination, *, allow_test=False):
    if split == 'test' and not allow_test:
        raise ValueError('Internal test preparation is only allowed after frozen selection')
    config = resources(); manifest_path = config['resources']['parent_split_manifest']
    manifest = load_json(manifest_path)
    parents = []
    for row in parent_records(manifest, split):
        mask = read_instance_mask(row['source_mask'])
        if mask.shape != (row['height'], row['width']):
            raise ValueError('Mask size mismatch')
        tiles = make_grid(row['width'], row['height'], core_size, halo)
        targets = assign_targets(mask, tiles)
        if sum(targets) != row['count']:
            raise ValueError('Count mismatch with fixed parent manifest')
        parents.append({k: row[k] for k in ['filename', 'source_image', 'group', 'split', 'width', 'height', 'count']})
        parents[-1]['targets'] = targets
    prepared = {'schema_version': 1, 'manifest_sha256': sha256(manifest_path),
                'core_size': core_size, 'halo': halo, 'split': split,
                'ownership': 'instance pixel-center centroid; half-open cores', 'parents': parents}
    save_json(prepared, destination)
    return prepared


def main():
    configure_runtime()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audit', action='store_true')
    parser.add_argument('--split', choices=['train', 'val'])
    parser.add_argument('--core-size', type=int, default=192)
    parser.add_argument('--halo', type=int, default=32)
    args = parser.parse_args()
    if args.audit:
        print(audit_training())
    elif args.split:
        result = prepare_split(args.split, args.core_size, args.halo,
                               f'data/derived/{args.split}_c{args.core_size}_h{args.halo}.json')
        print(f"Prepared {len(result['parents'])} parents; sum preserved")
    else:
        parser.error('Specify --audit or --split')


if __name__ == '__main__':
    main()
