"""Isolated core-region counting project scaffold. No trained model is implemented yet."""
