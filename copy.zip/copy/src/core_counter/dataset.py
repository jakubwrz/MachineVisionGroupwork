"""Lazy read-only parent images, explicit core masks, balanced parent sampling."""
from collections import OrderedDict
import random
from numbers import Integral
import numpy as np
import torch
from torch.utils.data import Dataset, Sampler
from PIL import Image, ImageEnhance
from .geometry import make_grid, extract_tile

MEAN = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
STD = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)


def tensor_tile(image, core_mask, augment=False):
    if augment:
        if random.random() < .5:
            image = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            core_mask = np.fliplr(core_mask).copy()
        if random.random() < .5:
            image = image.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
            core_mask = np.flipud(core_mask).copy()
        image = ImageEnhance.Brightness(image).enhance(random.uniform(.85, 1.15))
        image = ImageEnhance.Contrast(image).enhance(random.uniform(.85, 1.15))
        image = ImageEnhance.Color(image).enhance(random.uniform(.9, 1.1))
    rgb = torch.from_numpy(np.array(image, dtype=np.float32).transpose(2, 0, 1).copy()) / 255.
    core = torch.from_numpy(np.asarray(core_mask, dtype=np.float32).copy()).unsqueeze(0)
    return (rgb - MEAN) / STD, core


class CoreDataset(Dataset):
    def __init__(self, prepared, augment=False, cache_parents=4):
        self.prepared = prepared
        self.parents = prepared['parents']
        self.augment = augment
        self.cache_parents = cache_parents
        self.cache = OrderedDict()
        self.tiles, self.items, self.parent_indices = [], [], []
        if not isinstance(cache_parents, int) or cache_parents < 1:
            raise ValueError('cache_parents must be positive')
        for parent_index, parent in enumerate(self.parents):
            targets = parent['targets']
            if any(isinstance(v, bool) or not isinstance(v, Integral) or v < 0 for v in targets):
                raise ValueError('Core targets must be nonnegative integers')
            if (isinstance(parent['count'], bool) or not isinstance(parent['count'], Integral)
                    or parent['count'] < 0 or sum(targets) != parent['count']):
                raise ValueError('Core targets do not conserve parent count')
            tiles = make_grid(parent['width'], parent['height'], prepared['core_size'], prepared['halo'])
            if len(tiles) != len(parent['targets']):
                raise ValueError('Target/grid mismatch')
            self.tiles.append(tiles)
            indices = []
            for tile_index in range(len(tiles)):
                indices.append(len(self.items)); self.items.append((parent_index, tile_index))
            self.parent_indices.append(indices)

    def __len__(self):
        return len(self.items)

    def __getitem__(self, index):
        parent_index, tile_index = self.items[index]
        parent = self.parents[parent_index]
        if parent_index not in self.cache:
            with Image.open(parent['source_image']) as image:
                if image.size != (parent['width'], parent['height']):
                    raise ValueError('Parent image size changed')
                self.cache[parent_index] = image.convert('RGB')
            while len(self.cache) > self.cache_parents:
                self.cache.popitem(last=False)
        self.cache.move_to_end(parent_index)
        image, core_mask = extract_tile(self.cache[parent_index], self.tiles[parent_index][tile_index])
        rgb, core = tensor_tile(image, core_mask, self.augment)
        return {'rgb': rgb, 'core_mask': core, 'target': float(parent['targets'][tile_index]),
                'parent_index': parent_index, 'tile_index': tile_index}


class ParentBalancedSampler(Sampler):
    """Equal samples/parent, no density oversampling; contiguous parent for I/O.

    Each epoch selects at most k unique cores of each parent uniformly. Parent
    order is shuffled deterministically; all parents contribute equally when
    each has >=k tiles. No replacement is needed for this fixed-size dataset.
    """
    def __init__(self, dataset, tiles_per_parent=8, seed=20261116):
        self.indices = dataset.parent_indices
        if tiles_per_parent <= 0:
            raise ValueError('tiles_per_parent must be positive')
        self.k, self.seed, self.epoch = tiles_per_parent, seed, 0

    def set_epoch(self, epoch):
        self.epoch = epoch

    def __iter__(self):
        rng = random.Random(self.seed + self.epoch)
        parents = list(range(len(self.indices))); rng.shuffle(parents)
        for parent in parents:
            yield from rng.sample(self.indices[parent], min(self.k, len(self.indices[parent])))

    def __len__(self):
        return sum(min(self.k, len(indices)) for indices in self.indices)
