"""Count metrics computed on full parents, never patch classification accuracy."""
import math
import numpy as np


def count_metrics(truth, prediction):
    truth = np.asarray(truth, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    if truth.ndim != 1 or truth.shape != prediction.shape or not len(truth):
        raise ValueError('Expected nonempty equally shaped vectors')
    if not (np.isfinite(truth).all() and np.isfinite(prediction).all()):
        raise ValueError('Nonfinite counts')
    error = prediction - truth
    return {'n': len(truth), 'mae': float(np.abs(error).mean()),
            'rmse': float(np.sqrt(np.square(error).mean())), 'bias': float(error.mean())}


def round_total(value):
    if not math.isfinite(value) or value < 0:
        raise ValueError('Predictions must be finite and nonnegative')
    return int(math.floor(value + .5))


def summarize_parents(rows):
    truth = [r['target'] for r in rows]
    result = {'continuous': count_metrics(truth, [r['prediction'] for r in rows]),
              'rounded_after_sum': count_metrics(truth, [round_total(r['prediction']) for r in rows])}
    result['groups'] = {g: count_metrics([r['target'] for r in rows if r['group'] == g],
                                        [r['prediction'] for r in rows if r['group'] == g])
                        for g in sorted({r['group'] for r in rows})}
    result['equal_sequence_mae'] = float(np.mean([m['mae'] for m in result['groups'].values()]))
    result['density_bins'] = {}
    for name, low, high in [('0-19', 0, 20), ('20-79', 20, 80), ('80+', 80, math.inf)]:
        subset = [r for r in rows if low <= r['target'] < high]
        result['density_bins'][name] = (count_metrics([r['target'] for r in subset],
                                                     [r['prediction'] for r in subset]) if subset else {'n': 0})
    return result


def aggregate_tiles(parents, tile_predictions):
    """Reject duplicate/missing/invalid tiles rather than silently summing twice."""
    values = [[] for _ in parents]
    seen = set()
    for parent_index, tile_index, prediction in tile_predictions:
        if not 0 <= parent_index < len(parents):
            raise ValueError('Unknown parent')
        if not 0 <= tile_index < len(parents[parent_index]['targets']):
            raise ValueError('Unknown tile')
        key = (parent_index, tile_index)
        if key in seen:
            raise ValueError('Duplicate tile prediction')
        if not math.isfinite(prediction) or prediction < 0:
            raise ValueError('Invalid tile prediction')
        seen.add(key); values[parent_index].append((tile_index, prediction))
    rows = []
    for parent, predicted in zip(parents, values):
        if len(predicted) != len(parent['targets']):
            raise ValueError('Missing core prediction')
        predicted = [v for _, v in sorted(predicted)]
        rows.append({'filename': parent['filename'], 'group': parent['group'],
                     'target': parent['count'], 'prediction': math.fsum(predicted),
                     'tile_predictions': predicted})
    return rows
