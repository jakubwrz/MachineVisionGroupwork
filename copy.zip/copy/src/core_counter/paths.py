"""Application-level output guard; not an operating-system sandbox."""
from pathlib import Path
import hashlib
import shutil

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def output_path(value, *, project_root=PROJECT_ROOT):
    """Resolve an output strictly below this project; reject shared existing files."""
    root = Path(project_root).resolve()
    path = Path(value)
    candidate = (path if path.is_absolute() else root / path).resolve()
    if candidate == root or not candidate.is_relative_to(root):
        raise ValueError(f'Output escapes isolated project: {value}')
    if candidate.is_file() and candidate.stat().st_nlink > 1:
        raise ValueError(f'Output is a hardlinked/shared file: {candidate}')
    return candidate


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def copy_independent(source, destination, *, project_root=PROJECT_ROOT):
    """Copy bytes into a NEW regular file; refuse any existing destination."""
    raw_source = Path(source)
    if raw_source.is_symlink():
        raise ValueError('Use an explicit regular source file, not a symlink')
    src = raw_source.resolve()
    if not src.is_file():
        raise FileNotFoundError(src)
    dest = output_path(destination, project_root=project_root)
    if src == dest:
        raise ValueError('Source and destination must differ')
    if dest.exists() or dest.is_symlink():
        raise FileExistsError(f'Refusing to overwrite: {dest}')
    dest.parent.mkdir(parents=True, exist_ok=True)
    source_hash = sha256(src)
    # Exclusive creation prevents accidental overwrite, including a symlink race.
    with src.open('rb') as reader, dest.open('xb') as writer:
        shutil.copyfileobj(reader, writer, length=1024 * 1024)
    if dest.samefile(src) or dest.stat().st_nlink != 1:
        raise RuntimeError('Copy is not an independent regular file')
    if sha256(dest) != source_hash or sha256(src) != source_hash:
        raise RuntimeError('Source changed during copy or copy integrity failed')
    return {'source': str(src), 'destination': str(dest), 'sha256': source_hash,
            'bytes': dest.stat().st_size, 'independent_regular_copy': True}
