"""Deterministic, label-conserving core geometry (NumPy/Pillow only).

Background is ID 0; each distinct positive integer ID counts once, including
IDs with disconnected pixels. Coordinates refer to pixel centres (x+.5, y+.5).
Cores are half-open; context is never used to decide a target. Tile lists and
returned targets have matching order; ``index`` is a unique identifier, not an
array offset. No function writes files or modifies its inputs.
"""
from collections.abc import Mapping, Sequence
from numbers import Integral
from pathlib import Path

import numpy as np
from PIL import Image


__all__ = ["make_grid", "instance_centroids", "assign_targets",
           "read_instance_mask", "extract_tile"]


def _integer(value, name, minimum=0):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer, not {type(value).__name__}")
    value = int(value)
    if value < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    return value


def _mask(mask):
    if not isinstance(mask, np.ndarray):
        raise TypeError("mask must be a numpy.ndarray")
    if mask.ndim != 2 or not all(mask.shape):
        raise ValueError("mask must be a nonempty two-dimensional array")
    if mask.dtype.kind not in "iu":
        raise TypeError("mask IDs must have an integer dtype (not bool or float)")
    if mask.dtype.kind == "i" and np.any(mask < 0):
        raise ValueError("mask IDs must be nonnegative; 0 is background")
    return mask


def make_grid(width: int, height: int, core_size: int, halo: int) -> list[dict]:
    """Return a row-major partition, with fixed (core_size+2*halo) windows.

    Dimensions/core_size must be positive integers; halo is nonnegative.
    ``core`` and ``crop`` use original-image coordinates. Padding is black and
    ordered [left, top, right, bottom]; final cores are clipped, windows are not.
    """
    width = _integer(width, "width", 1)
    height = _integer(height, "height", 1)
    core_size = _integer(core_size, "core_size", 1)
    halo = _integer(halo, "halo")
    tiles = []
    for y in range(0, height, core_size):
        for x in range(0, width, core_size):
            window = [x - halo, y - halo, x + core_size + halo,
                      y + core_size + halo]
            crop = [max(0, window[0]), max(0, window[1]),
                    min(width, window[2]), min(height, window[3])]
            tiles.append({
                "index": len(tiles),
                "core": [x, y, min(width, x + core_size),
                         min(height, y + core_size)],
                "window": window,
                "crop": crop,
                "padding": [crop[0] - window[0], crop[1] - window[1],
                            window[2] - crop[2], window[3] - crop[3]],
            })
    return tiles


def instance_centroids(mask: np.ndarray) -> dict[int, tuple[float, float]]:
    """Return ascending-ID centroids of all pixels of each nonzero ID.

    Sparse/large IDs are not used as array indices and are never renumbered.
    A centroid may be on background, including between disconnected fragments.
    """
    _mask(mask)
    ys, xs = np.nonzero(mask)
    if not len(xs):
        return {}
    ids, inverse, counts = np.unique(mask[ys, xs], return_inverse=True,
                                     return_counts=True)
    xmeans = np.bincount(inverse, weights=xs) / counts + 0.5
    ymeans = np.bincount(inverse, weights=ys) / counts + 0.5
    return {int(instance_id): (float(x), float(y))
            for instance_id, x, y in zip(ids, xmeans, ymeans)}


def _quad(tile, name, *, signed=False):
    if name not in tile:
        raise ValueError(f"tile is missing {name}")
    values = tile[name]
    if not isinstance(values, (list, tuple, np.ndarray)) or len(values) != 4:
        raise ValueError(f"tile {name} must contain four integers")
    result = []
    for value in values:
        # Window origins can be negative; other geometry cannot.
        if signed:
            if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral):
                raise TypeError(f"tile {name} must contain integers")
            result.append(int(value))
        else:
            result.append(_integer(value, f"tile {name}"))
    return result


def _validate_tile(tile, width, height):
    if not isinstance(tile, Mapping):
        raise TypeError("each tile must be a mapping")
    if "index" not in tile:
        raise ValueError("tile is missing index")
    index = _integer(tile["index"], "tile index")
    core = _quad(tile, "core")
    window = _quad(tile, "window", signed=True)
    crop = _quad(tile, "crop")
    padding = _quad(tile, "padding")
    x0, y0, x1, y1 = core
    wx0, wy0, wx1, wy1 = window
    if not (0 <= x0 < x1 <= width and 0 <= y0 < y1 <= height):
        raise ValueError("tile core must be nonempty and inside the image")
    halo = x0 - wx0
    size = wx1 - wx0 - 2 * halo
    if (halo < 0 or y0 - wy0 != halo or size <= 0
            or wy1 - wy0 != wx1 - wx0
            or x1 != min(width, x0 + size)
            or y1 != min(height, y0 + size)):
        raise ValueError("tile window must describe a fixed square core plus equal halo")
    expected_crop = [max(0, wx0), max(0, wy0), min(width, wx1), min(height, wy1)]
    if crop != expected_crop:
        raise ValueError("tile crop must equal window clipped to the image")
    if padding != [crop[0] - wx0, crop[1] - wy0, wx1 - crop[2], wy1 - crop[3]]:
        raise ValueError("tile padding is inconsistent with window and crop")
    return index, core, window, crop, padding


def _validate_partition(cores, width, height):
    """Sweep x slabs: reject gaps/overlap even when the mask is all background."""
    events = {}
    for i, (x0, y0, x1, y1) in enumerate(cores):
        events.setdefault(x0, []).append((i, (y0, y1)))
        events.setdefault(x1, []).append((i, None))
    if not events or min(events) != 0 or max(events) != width:
        raise ValueError("tile cores must cover the complete image")
    active = {}
    for x in sorted(events):
        for i, interval in events[x]:
            if interval is None:
                del active[i]
            else:
                active[i] = interval
        if x == width:
            break
        end = 0
        for y0, y1 in sorted(active.values()):
            if y0 != end:
                raise ValueError("tile cores have an overlap or uncovered region")
            end = y1
        if end != height:
            raise ValueError("tile cores do not cover the complete image height")


def assign_targets(mask: np.ndarray, tiles) -> list[int]:
    """Count centroid owners in input tile order; never clip counts to six.

    Reject malformed metadata, duplicate indices, gaps or overlapping cores and
    any instance without exactly one owner. Full partition validation applies
    even for all-background masks. Inputs are not changed.
    """
    _mask(mask)
    if not isinstance(tiles, Sequence) or isinstance(tiles, (str, bytes)):
        raise TypeError("tiles must be a sequence of tile mappings")
    height, width = mask.shape
    validated = [_validate_tile(tile, width, height) for tile in tiles]
    indices = [tile[0] for tile in validated]
    if len(indices) != len(set(indices)):
        raise ValueError("tile indices must be unique")
    cores = [tile[1] for tile in validated]
    _validate_partition(cores, width, height)
    centroids = instance_centroids(mask)
    targets = [0] * len(tiles)
    for instance_id, (x, y) in centroids.items():
        owners = [i for i, (x0, y0, x1, y1) in enumerate(cores)
                  if x0 <= x < x1 and y0 <= y < y1]
        if len(owners) != 1:
            raise ValueError(f"instance {instance_id} has {len(owners)} core owners")
        targets[owners[0]] += 1
    if sum(targets) != len(centroids):
        raise ValueError("instance label conservation failed")
    return targets


def read_instance_mask(path: str | Path) -> np.ndarray:
    """Read raw palette/grayscale integer IDs; never convert palette to RGB/L.

    RGB/RGBA, floating-point, binary and multiframe images are rejected rather
    than guessed at. Returned data owns its memory after the image is closed.
    """
    with Image.open(path) as image:
        if image.mode not in {"P", "L", "I", "I;16", "I;16L", "I;16B", "I;16N"}:
            raise ValueError(f"unsupported instance mask mode: {image.mode}")
        if getattr(image, "n_frames", 1) != 1:
            raise ValueError("instance mask must contain exactly one frame")
        mask = np.array(image, copy=True)
    return _mask(mask)


def extract_tile(image: Image.Image, tile) -> tuple[Image.Image, np.ndarray]:
    """Return fixed-size RGB context and float32 {0,1} valid-core mask.

    Out-of-image context is black. On small/edge images, nominal core padding
    remains zero in core_mask: only real original-image core pixels are one.
    """
    if not isinstance(image, Image.Image):
        raise TypeError("image must be a PIL.Image.Image")
    width, height = image.size
    _integer(width, "image width", 1)
    _integer(height, "image height", 1)
    _, core, window, crop, padding = _validate_tile(tile, width, height)
    wx0, wy0, wx1, wy1 = window
    result = Image.new("RGB", (wx1 - wx0, wy1 - wy0), (0, 0, 0))
    result.paste(image.crop(tuple(crop)).convert("RGB"), tuple(padding[:2]))
    core_mask = np.zeros((wy1 - wy0, wx1 - wx0), dtype=np.float32)
    x0, y0, x1, y1 = core
    core_mask[y0 - wy0:y1 - wy0, x0 - wx0:x1 - wx0] = 1.0
    return result, core_mask
