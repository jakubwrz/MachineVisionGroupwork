"""Simple English desktop GUI for the packaged apple-counting models.

Drop an image on the window (or use Open Image) and the selected model runs
automatically. The result panel shows the predicted apple count and details.
"""
from pathlib import Path
import csv
import json
import os
import queue
import subprocess
import sys
import threading
import time
import uuid

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "vendor"))

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except Exception:
    DND_AVAILABLE = False

import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk

IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}

MODELS = {
    "Orchard (YOLO11n)": {
        "kind": "orchard",
        "mode": "orchard",
        "selection": "results/optimization/selection.json",
    },
    "Tiled (experimental)": {
        "kind": "orchard",
        "mode": "orchard",
        "selection": "results/optimization/s_tiled/selection.json",
    },
    "Patch (0-6 apples)": {
        "kind": "orchard",
        "mode": "patch",
        "selection": None,
    },
    "Core (experimental)": {
        "kind": "core",
        "mode": "core",
        "selection": "runs/core_v1/selection.json",
    },
}


class AppleCounterApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Apple Counter")
        self.root.geometry("960x620")
        self.root.minsize(880, 580)
        self.root.configure(bg="#eef2f6")

        self.closed = False
        self.busy = False
        self.image_path = None
        self.current_image = None
        self.photo = None
        self.queue = queue.Queue()

        self.model_var = tk.StringVar(value=next(iter(MODELS)))
        self.gpu_var = tk.BooleanVar(value=False)
        self.count_var = tk.StringVar(value="—")
        self.detail_var = tk.StringVar(value="No image loaded.")
        self.status_var = tk.StringVar(value="Ready.")

        self._build_ui()
        self._configure_dnd()
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
        style.configure("TButton", font=("Segoe UI", 10), padding=(10, 6))
        style.configure("TCombobox", font=("Segoe UI", 10))

        header = tk.Frame(self.root, bg="#0f172a", height=66)
        header.pack(fill="x")
        tk.Label(
            header,
            text="Apple Counter",
            bg="#0f172a",
            fg="white",
            font=("Segoe UI", 20, "bold"),
        ).pack(side="left", padx=20, pady=16)
        tk.Label(
            header,
            text="Drop an image to count apples",
            bg="#0f172a",
            fg="#94a3b8",
            font=("Segoe UI", 10),
        ).pack(side="left", padx=6)

        close_button = tk.Button(
            header,
            text="Close",
            command=self.close,
            bg="#dc2626",
            fg="white",
            activebackground="#b91c1c",
            activeforeground="white",
            relief="flat",
            font=("Segoe UI", 10, "bold"),
            padx=16,
            pady=6,
            cursor="hand2",
        )
        close_button.pack(side="right", padx=20, pady=16)

        body = tk.Frame(self.root, bg="#eef2f6")
        body.pack(fill="both", expand=True, padx=18, pady=14)
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=0, minsize=300)
        body.rowconfigure(0, weight=1)

        left = tk.Frame(body, bg="#eef2f6")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)

        self.canvas = tk.Canvas(
            left,
            bg="#111827",
            highlightthickness=2,
            highlightbackground="#334155",
            highlightcolor="#0ea5e9",
        )
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.canvas.bind("<Configure>", lambda _event: self._render_preview())

        tk.Label(
            left,
            text="Drag & drop a full orchard image here, or click Open Image.",
            bg="#eef2f6",
            fg="#64748b",
            font=("Segoe UI", 9),
        ).grid(row=1, column=0, sticky="w", pady=(8, 0))

        result = tk.Frame(
            body,
            bg="white",
            highlightbackground="#d7dee7",
            highlightthickness=1,
        )
        result.grid(row=0, column=1, sticky="nsew")
        result.columnconfigure(0, weight=1)

        tk.Label(
            result,
            text="RESULT",
            bg="white",
            fg="#64748b",
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w", padx=20, pady=(18, 4))

        self.count_label = tk.Label(
            result,
            textvariable=self.count_var,
            bg="white",
            fg="#0f766e",
            font=("Segoe UI", 52, "bold"),
        )
        self.count_label.pack(anchor="w", padx=18)

        tk.Label(
            result,
            text="apples",
            bg="white",
            fg="#64748b",
            font=("Segoe UI", 10),
        ).pack(anchor="w", padx=21, pady=(0, 10))

        ttk.Separator(result, orient="horizontal").pack(fill="x", padx=20, pady=8)

        self.detail_label = tk.Label(
            result,
            textvariable=self.detail_var,
            bg="white",
            fg="#334155",
            justify="left",
            anchor="nw",
            wraplength=260,
            font=("Segoe UI", 9),
        )
        self.detail_label.pack(fill="x", padx=20, pady=(4, 8))

        self.status_label = tk.Label(
            result,
            textvariable=self.status_var,
            bg="white",
            fg="#0369a1",
            justify="left",
            anchor="w",
            wraplength=260,
            font=("Segoe UI", 9, "bold"),
        )
        self.status_label.pack(fill="x", padx=20, pady=(0, 18))

        footer = tk.Frame(self.root, bg="#eef2f6")
        footer.pack(fill="x", padx=18, pady=(0, 16))

        tk.Label(
            footer,
            text="Model",
            bg="#eef2f6",
            fg="#334155",
            font=("Segoe UI", 10),
        ).pack(side="left")

        self.model_combo = ttk.Combobox(
            footer,
            textvariable=self.model_var,
            values=list(MODELS),
            state="readonly",
            width=24,
        )
        self.model_combo.pack(side="left", padx=(8, 10))
        self.model_combo.bind("<<ComboboxSelected>>", self._model_changed)

        self.detect_button = ttk.Button(
            footer, text="Detect", command=self.detect_current, state="disabled"
        )
        self.detect_button.pack(side="left", padx=4)

        self.open_button = ttk.Button(
            footer, text="Open Image...", command=self.choose_file
        )
        self.open_button.pack(side="left", padx=4)

        self.clear_button = ttk.Button(
            footer, text="Clear", command=self.clear, state="disabled"
        )
        self.clear_button.pack(side="left", padx=4)

        self.gpu_check = ttk.Checkbutton(
            footer, text="Use GPU", variable=self.gpu_var
        )
        self.gpu_check.pack(side="right", padx=4)

    def _configure_dnd(self):
        if not DND_AVAILABLE:
            self.status_var.set("Drag-and-drop unavailable; use Open Image.")
            return
        try:
            self.root.drop_target_register(DND_FILES)
            self.root.dnd_bind("<<Drop>>", self._on_drop)
            self.root.dnd_bind("<<DropEnter>>", self._on_drag_enter)
            self.root.dnd_bind("<<DropLeave>>", self._on_drag_leave)
        except Exception as exc:
            self.status_var.set(f"Drag-and-drop unavailable: {exc}")

    # -------------------------------------------------------------- drag/drop
    def _on_drag_enter(self, event):
        self.canvas.configure(highlightbackground="#0ea5e9")
        return event.action

    def _on_drag_leave(self, event):
        self.canvas.configure(highlightbackground="#334155")
        return event.action

    def _on_drop(self, event):
        self.canvas.configure(highlightbackground="#334155")
        if self.busy:
            self.status_var.set("Please wait for the current detection.")
            return event.action
        try:
            paths = self.root.tk.splitlist(event.data)
        except Exception:
            paths = event.data if isinstance(event.data, (tuple, list)) else [event.data]
        paths = [str(path) for path in paths if str(path).strip()]
        if not paths:
            self._fail("No file was dropped.")
            return event.action
        if len(paths) > 1:
            self.status_var.set("Only the first dropped image is used.")
        self.load_path(paths[0])
        return event.action

    # ---------------------------------------------------------------- actions
    def choose_file(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Open image",
            filetypes=[
                ("Images", "*.png *.jpg *.jpeg *.bmp *.webp"),
                ("All files", "*.*"),
            ],
        )
        if path:
            self.load_path(path)

    def load_path(self, value):
        path = Path(value)
        if not path.is_file():
            self._fail("Please drop an image file, not a folder.")
            return
        if path.suffix.lower() not in IMAGE_SUFFIXES:
            self._fail("Unsupported image type. Use PNG, JPG, JPEG, BMP or WEBP.")
            return
        try:
            with Image.open(path) as image:
                image.load()
                preview = image.convert("RGB")
        except Exception as exc:
            self._fail(f"Cannot open image: {exc}")
            return

        self.image_path = path
        self.current_image = preview
        self._render_preview()
        self.count_var.set("—")
        self.detail_var.set(f"Model: {self.model_var.get()}\nFile: {path.name}")
        self.status_var.set("Detecting...")
        self.detect_button.configure(state="normal")
        self.clear_button.configure(state="normal")
        self._start_detection()

    def detect_current(self):
        if self.busy:
            return
        if self.image_path is None:
            self.status_var.set("Open or drop an image first.")
            return
        self._start_detection()

    def clear(self):
        if self.busy:
            return
        self.image_path = None
        self.current_image = None
        self.photo = None
        self.count_var.set("—")
        self.detail_var.set("No image loaded.")
        self.status_var.set("Ready.")
        self.detect_button.configure(state="disabled")
        self.clear_button.configure(state="disabled")
        self._render_preview()

    def _model_changed(self, _event=None):
        if self.busy:
            return
        if self.image_path is not None:
            self.status_var.set("Model changed. Click Detect to rerun.")

    # -------------------------------------------------------------- detection
    def _start_detection(self):
        if self.busy or self.image_path is None:
            return
        self.busy = True
        self._set_controls(False)
        self.count_var.set("—")
        self.status_var.set("Detecting...")
        model_name = self.model_var.get()
        path = self.image_path
        use_gpu = self.gpu_var.get()
        while not self.queue.empty():
            try:
                self.queue.get_nowait()
            except queue.Empty:
                break
        thread = threading.Thread(
            target=self._worker, args=(path, model_name, use_gpu), daemon=True
        )
        thread.start()
        self.root.after(100, self._poll_queue)

    def _worker(self, path, model_name, use_gpu):
        start = time.perf_counter()
        try:
            result = self._run_model(path, model_name, use_gpu)
            result["elapsed"] = time.perf_counter() - start
            self.queue.put(("result", result))
        except Exception as exc:
            self.queue.put(("error", str(exc)))

    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.queue.get_nowait()
                if kind == "result":
                    self._show_result(payload)
                else:
                    self._show_error(payload)
        except queue.Empty:
            pass
        if self.busy and not self.closed:
            self.root.after(100, self._poll_queue)

    def _run_model(self, path, model_name, use_gpu):
        spec = MODELS[model_name]
        folder = ROOT / "gui_output" / (
            time.strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
        )
        folder.mkdir(parents=True, exist_ok=False)
        environment = self._environment()
        device = "cuda" if use_gpu else "cpu"

        if spec["kind"] == "core":
            command = [
                sys.executable,
                "-m",
                "core_counter.predict",
                "--image",
                str(path),
                "--selection",
                "runs/core_v1/selection.json",
                "--output",
                str(folder / "result.json"),
                "--device",
                device,
            ]
        else:
            command = [
                sys.executable,
                "-m",
                "apple_counter.predict",
                str(path),
                "--mode",
                spec["mode"],
                "--out",
                str(folder),
                "--device",
                "0" if device == "cuda" else "cpu",
            ]
            if spec.get("selection"):
                command += ["--selection", spec["selection"]]

        completed = subprocess.run(
            command,
            cwd=ROOT,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=900,
        )
        if completed.returncode != 0:
            output = (completed.stderr or completed.stdout or "").strip()
            raise RuntimeError(
                f"Detection failed (exit {completed.returncode}).\n{output[-1500:]}"
            )

        if spec["kind"] == "core":
            data = json.loads((folder / "result.json").read_text(encoding="utf-8"))
            continuous = float(data["prediction"])
            count = int(data["rounded_after_sum"])
            annotated = folder / "result.png"
            detail = (
                f"Model: {model_name}\n"
                f"File: {path.name}\n"
                f"Core sum: {continuous:.2f}\n"
                f"Rounded: {count}\n"
                f"Output: {folder.name}"
            )
            return {
                "count": str(count),
                "detail": detail,
                "annotated": annotated,
                "status": "Done.",
            }

        with (folder / "counts.csv").open(newline="", encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream))
        if not rows:
            raise RuntimeError("The model produced no result row.")
        count = int(rows[0]["predicted_count"])
        images = sorted(folder.glob("*.jpg"))
        annotated = images[0] if images else None
        detail = (
            f"Model: {model_name}\n"
            f"File: {path.name}\n"
            f"Count: {count}\n"
            f"Output: {folder.name}"
        )
        if spec["mode"] == "patch":
            detail += "\nNote: patch model supports 0-6 apples only."
        return {
            "count": str(count),
            "detail": detail,
            "annotated": annotated,
            "status": "Done.",
        }

    def _environment(self):
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(ROOT / "src")
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        environment["PYTHONIOENCODING"] = "utf-8"
        for key, relative in {
            "TORCH_HOME": "cache/torch",
            "MPLCONFIGDIR": "cache/matplotlib",
            "YOLO_CONFIG_DIR": "cache/ultralytics",
            "TEMP": "tmp",
            "TMP": "tmp",
        }.items():
            target = ROOT / relative
            target.mkdir(parents=True, exist_ok=True)
            environment[key] = str(target)
        return environment

    # ---------------------------------------------------------------- display
    def _show_result(self, result):
        self.busy = False
        self._set_controls(True)
        self.count_var.set(result["count"])
        detail = result["detail"] + f"\nTime: {result['elapsed']:.1f} s"
        self.detail_var.set(detail)
        self.status_var.set(result["status"])
        annotated = result.get("annotated")
        if annotated and Path(annotated).is_file():
            try:
                with Image.open(annotated) as image:
                    self.current_image = image.convert("RGB")
                self._render_preview()
            except Exception:
                pass

    def _show_error(self, message):
        self.busy = False
        self._set_controls(True)
        self.count_var.set("—")
        self.detail_var.set(message)
        self.status_var.set("Error")

    def _fail(self, message):
        self.count_var.set("—")
        self.detail_var.set(message)
        self.status_var.set("Error")

    def _set_controls(self, enabled):
        self.model_combo.configure(state="readonly" if enabled else "disabled")
        state = "normal" if enabled else "disabled"
        self.detect_button.configure(state=state)
        self.open_button.configure(state=state)
        self.clear_button.configure(state=state)
        self.gpu_check.configure(state=state)

    def _render_preview(self):
        width = max(self.canvas.winfo_width(), 2)
        height = max(self.canvas.winfo_height(), 2)
        self.canvas.delete("all")
        if self.current_image is None:
            self.canvas.create_text(
                width / 2,
                height / 2,
                text="Drag & drop an image here\n\nor click Open Image",
                fill="#94a3b8",
                font=("Segoe UI", 16),
                justify="center",
            )
            return
        image = self.current_image.copy()
        image.thumbnail((max(100, width - 24), max(100, height - 24)))
        self.photo = ImageTk.PhotoImage(image)
        self.canvas.create_image(width / 2, height / 2, image=self.photo)

    def close(self):
        self.closed = True
        try:
            self.root.destroy()
        except tk.TclError:
            pass


def main():
    root = TkinterDnD.Tk() if DND_AVAILABLE else tk.Tk()
    AppleCounterApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
