"""Launch a packaged model from this folder; tested on CPU."""
from pathlib import Path
import argparse
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('model', choices=['patch', 'orchard', 'tiled', 'core'])
    parser.add_argument('source', nargs='?', default=None)
    parser.add_argument('output', nargs='?', default='predictions')
    parser.add_argument('--device', choices=['cpu', 'cuda'], default='cpu')
    args = parser.parse_args()

    if args.source is None:
        args.source = ('demo/patch' if args.model == 'patch' else
                       'demo/orchard/dataset1_back_1.png' if args.model == 'core' else
                       'demo/orchard')
    env = os.environ.copy()
    env['PYTHONPATH'] = str(ROOT / 'src')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    for key, relative in {'TORCH_HOME': 'cache/torch', 'MPLCONFIGDIR': 'cache/matplotlib',
                          'YOLO_CONFIG_DIR': 'cache/ultralytics', 'TEMP': 'tmp',
                          'TMP': 'tmp'}.items():
        path = ROOT / relative
        path.mkdir(parents=True, exist_ok=True)
        env[key] = str(path)

    if args.model == 'core':
        command = [sys.executable, '-m', 'core_counter.predict', '--image', args.source,
                   '--selection', 'runs/core_v1/selection.json',
                   '--output', str(Path(args.output) / 'result.json'),
                   '--device', args.device]
    else:
        command = [sys.executable, '-m', 'apple_counter.predict', args.source,
                   '--mode', 'patch' if args.model == 'patch' else 'orchard',
                   '--out', args.output,
                   '--device', '0' if args.device == 'cuda' else 'cpu']
        selection = {'orchard': 'results/optimization/selection.json',
                     'tiled': 'results/optimization/s_tiled/selection.json'}.get(args.model)
        if selection:
            command += ['--selection', selection]
    subprocess.run(command, cwd=ROOT, env=env, check=True)


if __name__ == '__main__':
    main()
