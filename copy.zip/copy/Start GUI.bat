@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found on PATH.
    echo Install the requirements first, then run: python gui.py
    pause
    exit /b 1
)
python gui.py
if errorlevel 1 pause
