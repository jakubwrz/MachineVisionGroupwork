param(
    [ValidateSet('patch','orchard','tiled','core')]
    [string]$Model = 'orchard',
    [string]$Source = 'demo/orchard',
    [string]$Output = 'predictions',
    [ValidateSet('cpu','cuda')]
    [string]$Device = 'cpu',
    [string]$Python = 'python'
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:PYTHONPATH = "$PSScriptRoot\src"
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:TORCH_HOME = "$PSScriptRoot\cache\torch"
$env:MPLCONFIGDIR = "$PSScriptRoot\cache\matplotlib"
$env:YOLO_CONFIG_DIR = "$PSScriptRoot\cache\ultralytics"
$env:TEMP = "$PSScriptRoot\tmp"
$env:TMP = $env:TEMP
foreach ($dir in @($env:TORCH_HOME, $env:MPLCONFIGDIR, $env:YOLO_CONFIG_DIR, $env:TEMP)) {
    New-Item -ItemType Directory -Force $dir | Out-Null
}
$orchDevice = if ($Device -eq 'cuda') { '0' } else { 'cpu' }
switch ($Model) {
    'patch' {
        & $Python -m apple_counter.predict $Source --mode patch --out $Output --device $orchDevice
    }
    'orchard' {
        & $Python -m apple_counter.predict $Source --mode orchard --selection results/optimization/selection.json --out $Output --device $orchDevice
    }
    'tiled' {
        & $Python -m apple_counter.predict $Source --mode orchard --selection results/optimization/s_tiled/selection.json --out $Output --device $orchDevice
    }
    'core' {
        & $Python -m core_counter.predict --image $Source --selection runs/core_v1/selection.json --output "$Output\result.json" --device $Device
    }
}
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
